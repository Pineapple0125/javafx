package Main;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import utils.XMLUtils;

import java.io.File;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainAPP extends Application{

    public static Stage staticScreen;

    private double mouse_X;
    private double mouse_Y;

    public VBox vBoxSong = new VBox(10);

    //当前播放时间的前一秒 -- 设置滚动条
    private int preSecond;






    // 总时间
    private Label labelTotalTime;
    //已经播放的时间
    private Label labelPlayTime;
    //播放按钮
    private ImageView buttonPlayImage;
    private Label labelPlay;

    private  int PlayMode = 1; // 列表循环 随机播放 单曲循环

    private Slider sliderSong; //播放时间滚动条对象

    private final ArrayList<ASound> songList = new ArrayList<>();  //  曲目类的所有歌曲存放在这里

    private MediaPlayer mediaPlayer; // 目前播放的对象
    private ASound playingSound; //存储现在正在播放的歌曲
    private int playingSoundID;  // 歌曲索引
    private final ArrayList<ASound> stack = new ArrayList<>(); //  使用栈对付上一首的按钮

    private void playMusic(ASound sound){
        playingSound = sound;
        for (int i = 0; i < this.vBoxSong.getChildren().size(); i++) {
            vBoxSong.getChildren().get(i).setStyle("-fx-background-color: white");
        }

        URI uri = new File(sound.filePath).toURI(); // 获取本地uri对象
        Media media = new Media(uri.toString());
        mediaPlayer = new MediaPlayer(media);
        this.labelTotalTime.setText(sound.totalStringTime);
        this.sliderSong.setMax(sound.totalIntTime);
        this.sliderSong.setMajorTickUnit(1);//每次动一格
        //设置初始值
        this.sliderSong.setValue(0);
        preSecond = 0;

        // 将列表中的歌曲设为高亮
        vBoxSong.getChildren().get(playingSoundID).setStyle("-fx-border-color:#FFB90F;" + "-fx-border-width:1px;");
        mediaPlayer.play();
        this.buttonPlayImage.setImage(new Image("image/stop.png"));
        this.labelPlay.setOnMouseEntered(event -> {buttonPlayImage.setImage(new Image("image/start.png"));});
        this.labelPlay.setOnMouseExited(event -> {buttonPlayImage.setImage(new Image("image/stop.png"));});
        mediaPlayer.currentTimeProperty().addListener(new ChangeListener<Duration>() {
            @Override
            public void changed(ObservableValue<? extends Duration> observable,
                                Duration oldValue, Duration newValue) {
                // 播放前后的时间
                // 每秒动一下 用秒操作
                int currentSecond = (int) newValue.toSeconds();

                // 设置滚动条 一秒一次
                if(currentSecond == preSecond + 1){
                    // 设置滚动条
                    sliderSong.setValue(sliderSong.getValue()+1);
                    // 设置前一秒
                    preSecond++;
                    // 设置新的播放时间
                    Date date = new Date();
                    date.setTime((int)sliderSong.getValue()*1000);
                    labelPlayTime.setText(new SimpleDateFormat("mm:ss").format(date));
                }
            }
        });


        // 当进度条到最后的时候
        mediaPlayer.setOnEndOfMedia(()->{
            stack.add(playingSound);
            // 停止播放器
            this.mediaPlayer.stop();
            // 根据当前播放模式选择下一首
            switch (this.PlayMode){
                case 1: // 乱序播放
                    Random random = new Random();
                    playingSoundID = this.songList.indexOf(playingSound);
                    int number = random.nextInt(this.vBoxSong.getChildren().size());
                    this.playingSoundID += number;
                    if (this.playingSoundID >= this.vBoxSong.getChildren().size()){
                        playingSoundID %= number;
                    }
                    break;
                case 2: // 顺序播放
                    this.playingSoundID++;
                    if (this.playingSoundID >= this.vBoxSong.getChildren().size()){
                        this.playingSoundID = 0;
                    }
                    break;
                case 3: // 单曲循环

                    break;
            }
            playMusic(songList.get(playingSoundID));

        });

    }

    private void addASound(ASound aSound){
        songList.add(aSound);
        Label songName = new Label(aSound.SoundName);
        songName.setStyle("-fx-font-size: 15");
        songName.setMinHeight(0);
        songName.setPrefHeight(25);
        songName.setPrefWidth(315);
        songName.setTextFill(Color.rgb(139, 69, 19));
        //这里有一个移入高亮
        songName.setOnMouseEntered(event -> songName.setTextFill(Color.rgb(255, 127, 0)));
        songName.setOnMouseExited(event -> songName.setTextFill(Color.rgb(139, 69, 19)));

        songName.setOnMouseClicked(event -> {
            if (event.getClickCount() ==2){
                playingSoundID = songList.indexOf(aSound);
                if (mediaPlayer != null){
                    stack.add(playingSound);
                    mediaPlayer.stop();
                }
                playMusic(aSound);
            }
        });

        // 垃圾桶;
        ImageView iv3 = new ImageView("image/ash-bin_dark.png");
        iv3.setFitWidth(20);
        iv3.setPreserveRatio(true);
        Label trash = new Label("",iv3);
        trash.setMinHeight(0);
        trash.setMinWidth(0);
        trash.setPrefWidth(20);
        trash.setPrefHeight(20);
        trash.setOnMouseEntered(event -> iv3.setImage(new Image("image/ash-bin_colorful.png")));
        trash.setOnMouseExited(event -> iv3.setImage(new Image("image/ash-bin_dark.png")));

        HBox songHBox = new HBox(10);//间距10
        songHBox.getChildren().addAll(songName,trash);
        songHBox.setPadding(new Insets(20,5,20,10));
        songHBox.setStyle("-fx-background-color: white");
        vBoxSong.getChildren().add(songHBox);
        trash.setOnMouseClicked(event -> {
            // 弹出提示
            try {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("确认删除");
                alert.setHeaderText("你确认要删除歌曲【"+songName.getText()+"】");
                Optional<ButtonType> buttonType = alert.showAndWait();
                if (buttonType.get() == ButtonType.OK){
                    XMLUtils.deleteSound(songName.getText().trim());
                    this.vBoxSong.getChildren().remove(songHBox);
                    System.out.println("success");

                }
            }catch (Exception e){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("删除失败 请检查当前目录完整性 或联系相关技术人员");
            }
        });
    }

    private BorderPane getTopPane(){
        // 设置右侧的那几个按钮
        // 最大化按钮
        ImageView max = new ImageView("image/minimal.png");
        max.setFitWidth(30);
        max.setFitHeight(30);

//        最小化按钮
        ImageView min = new ImageView("image/while__.png");
        min.setFitWidth(25);
        min.setFitHeight(25);

        Label label1 = new Label("",min);
        label1.setMinWidth(0);
        label1.setMinHeight(0);
        label1.setPrefHeight(25);
        label1.setPrefWidth(25);

        label1.setOnMouseEntered(event -> min.setImage(new Image("image/black__.png")));
        label1.setOnMouseExited(event -> min.setImage(new Image("image/while__.png")));
        // 鼠标点击
        label1.setOnMouseClicked(event -> staticScreen.setIconified(true));

//        关闭按钮
        ImageView close = new ImageView("image/black_X.png");
        close.setFitWidth(25);
        close.setFitHeight(25);

        Label label2 = new Label("",close);
        label2.setMinWidth(0);
        label2.setMinHeight(0);
        label2.setPrefHeight(25);
        label2.setPrefWidth(25);

        label2.setOnMouseEntered(event -> close.setImage(new Image("image/red_X.png")));
        label2.setOnMouseExited(event -> close.setImage(new Image("image/black_X.png")));
        label2.setOnMouseClicked(event -> {
            // 后期在这里有一个记录播放歌曲的东西
            System.exit(0);
        });

        HBox hBox1 = new HBox(10); //内部元素之间的间距为10
        hBox1.setPadding(new Insets(0,10,0,0));
        hBox1.setAlignment(Pos.CENTER_RIGHT);
        hBox1.setPrefWidth(150);
        hBox1.setPrefHeight(30);
        hBox1.getChildren().addAll(label1,label2);

        // 设置一个装饰用的紫线
        Rectangle rect = new Rectangle();
        rect.setX(0);
        rect.setY(0);
        rect.setWidth(100);
        rect.setHeight(5);
        // 设置背景色 渐变 stop 表示梯度
        Stop[] stops =new Stop[]{
                new Stop(0,Color.rgb(205, 149, 12)),
                new Stop(0.5,Color.rgb(238, 173, 14)),
                new Stop(1,Color.rgb(255, 185, 15))
        }; // 一个渐变的操作
        rect.setFill(new LinearGradient(0,0,1,1,true, CycleMethod.NO_CYCLE,stops));

        BorderPane topPane = new BorderPane();
        topPane.setBottom(rect); // 设置到底部了
        topPane.setRight(hBox1);
        topPane.setStyle("-fx-background-color: rgb(255, 193, 37);");

        //将红线的宽度和屏幕保持一致
        rect.widthProperty().bind(staticScreen.widthProperty());

        // 设置 拖拽功能

        topPane.setOnMousePressed(event -> { // 鼠标点击
            // 记录鼠标相对于窗口的坐标x，y
            mouse_X = event.getSceneX();
            mouse_Y = event.getSceneY();
        });
        topPane.setOnMouseDragged(event -> {
            staticScreen.setX(event.getScreenX()-mouse_X);
            staticScreen.setY(event.getScreenY()-mouse_Y);
        });



        return topPane;
    }
    private BorderPane getCenterPane(){

        List<ASound> groupList = XMLUtils.readAllSound();

        // 将每个歌单名字分装成hbox
        for (ASound sound:groupList){
            addASound(sound);
        }

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setStyle("    -fx-padding: 0;\n" +
                "    -fx-background-color: transparent;\n" +
                "    -fx-border-color: transparent;\n" +
                "    -fx-hbar-policy: never;\n" +
                "    -fx-vbar-policy: never;");
        scrollPane.setContent(vBoxSong);
        BorderPane CenterPane = new BorderPane();
        CenterPane.setCenter(scrollPane);

        return CenterPane;
    }
    private BorderPane getBottomPane() {
        // 左侧的三个按钮
        // 上一首
        ImageView imageView1 = new ImageView("image/last.png");
        imageView1.setFitHeight(50);
        imageView1.setFitWidth(50);
        Label label1 = new Label("",imageView1);
        label1.setOnMouseEntered(event -> imageView1.setImage(new Image("image/smile_left.png")));
        label1.setOnMouseExited(event -> imageView1.setImage(new Image("image/last.png")));
        label1.setOnMouseClicked(event -> {
            if(this.mediaPlayer != null){
                if (stack.size() != 0) {
                    this.mediaPlayer.stop();
                    ASound lastSound = stack.remove(stack.size() - 1);
                    playingSoundID = songList.indexOf(lastSound);
                    playMusic(lastSound);
                }
            }


        });
        // 播放按钮
        buttonPlayImage = new ImageView("image/start.png");
        buttonPlayImage.setFitHeight(60);
        buttonPlayImage.setFitWidth(60);
        labelPlay = new Label("",buttonPlayImage);
//        labelPlay.setOnMouseEntered(event -> buttonPlayImage.setImage(new Image("image/stop.png")));
//        labelPlay.setOnMouseExited(event -> buttonPlayImage.setImage(new Image("image/start.png")));
        labelPlay.setOnMouseClicked(event -> {
            if (mediaPlayer != null){
                //如果正在播放 暂停
                if (this.mediaPlayer.getStatus() == MediaPlayer.Status.PLAYING){
                    this.mediaPlayer.pause();
                    // 设置播放按钮图标为播放
                    buttonPlayImage.setImage(new Image("image/start.png"));
                    labelPlay.setOnMouseEntered(event_0 -> buttonPlayImage.setImage(new Image("image/stop.png")));
                    labelPlay.setOnMouseExited(event_0 -> buttonPlayImage.setImage(new Image("image/start.png")));
                }else if (this.mediaPlayer.getStatus() == MediaPlayer.Status.PAUSED){
                    this.mediaPlayer.play();
                    buttonPlayImage.setImage(new Image("image/stop.png"));
                    labelPlay.setOnMouseEntered(event_0 -> buttonPlayImage.setImage(new Image("image/start.png")));
                    labelPlay.setOnMouseExited(event_0 -> buttonPlayImage.setImage(new Image("image/stop.png")));
                }
            }
        });

        // 下一首
        ImageView imageView3 = new ImageView("image/next.png");
        imageView3.setFitHeight(50);
        imageView3.setFitWidth(50);
        Label label3 = new Label("",imageView3);
        label3.setOnMouseEntered(event -> imageView3.setImage(new Image("image/smile_right.png")));
        label3.setOnMouseExited(event -> imageView3.setImage(new Image("image/next.png")));
        label3.setOnMouseClicked(event -> {
            if(this.mediaPlayer != null) {
                stack.add(playingSound);
                this.mediaPlayer.stop();  // 停止播放器
                // 根据当前播放模式选择下一首
                switch (this.PlayMode) {
                    case 1: // 乱序播放
                        Random random = new Random();
                        playingSoundID = this.songList.indexOf(playingSound);
                        int number = random.nextInt(this.vBoxSong.getChildren().size());
                        this.playingSoundID += number;
                        if (this.playingSoundID >= this.vBoxSong.getChildren().size()) {
                            playingSoundID %= this.vBoxSong.getChildren().size();
                        }
                        break;
                    case 2: // 顺序播放
                        this.playingSoundID++;
                        if (this.playingSoundID >= this.vBoxSong.getChildren().size()) {
                            this.playingSoundID = 0;
                        }
                        break;
                    case 3: // 单曲循环

                        break;
                }
                playMusic(songList.get(playingSoundID));
            }
        });

        //**************************中间滚动条*********************************

        // 已经播放的标签
        labelPlayTime = new Label("00:00");
        labelPlayTime.setPrefHeight(40);
        labelPlayTime.setPrefHeight(50);
        labelPlayTime.setTextFill(Color.rgb(139, 117, 0));
        labelPlayTime.setAlignment(Pos.CENTER);
        labelPlayTime.setPadding(new Insets(0,6,0,3));

        // 滚动条
        sliderSong = new Slider();
        sliderSong.setMinWidth(0);
        sliderSong.setMinHeight(0);
        sliderSong.setPrefHeight(12);
        sliderSong.setPrefWidth(500);
        sliderSong.getStylesheets().add("css/music_slide.css");

        // 进度条
        ProgressBar progressBar = new ProgressBar();
        progressBar.setProgress(0);
        progressBar.setMinWidth(0);
        progressBar.setMinHeight(0);

        progressBar.setMaxWidth(5000);
        progressBar.setPrefWidth(300);
        progressBar.getStylesheets().add("css/music_slide.css");
        // 使用栈的模板来存储两个滚动条
        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(progressBar,sliderSong);

        // 当滚动条值发生变化时
        sliderSong.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                if (mediaPlayer!= null){
                    progressBar.setProgress((newValue.doubleValue()+1)/playingSound.totalIntTime);
                }
            }
        });

        //Slider 的鼠标抬起事件
        sliderSong.setOnMouseReleased(event -> {
            if (mediaPlayer != null){
                Duration duration = new Duration(sliderSong.getValue()*1000);
                mediaPlayer.seek(duration);

                // 同时设计label
                Date data = new Date();
                data.setTime((long) mediaPlayer.getCurrentTime().toMillis());
                labelPlayTime.setText(new SimpleDateFormat("mm:ss").format(data));
                preSecond = (int)duration.toSeconds()-1;
            }
        });

//        总时间标签
        labelTotalTime = new Label("00:00");
        labelTotalTime.setPrefHeight(40);
        labelTotalTime.setPrefWidth(50);
        labelTotalTime.setTextFill(Color.rgb(139, 117, 0));
        labelTotalTime.setAlignment(Pos.CENTER);

        BorderPane borderPane = new BorderPane();

        borderPane.setLeft(labelPlayTime);
        borderPane.setCenter(stackPane);
        borderPane.setRight(labelTotalTime);
        //播放模式图片
        ImageView imageView5 = new ImageView("image/随机播放.png");
        imageView5.setFitWidth(25);
        imageView5.setFitHeight(25);
        Label label6 = new Label("",imageView5);
        label6.setPadding(new Insets(15,0,0,0));
        label6.setOnMouseEntered(event -> label6.setCursor(Cursor.HAND));
        label6.setOnMouseExited(event -> label6.setCursor(Cursor.DEFAULT));
        label6.setOnMouseClicked(event -> {
            // 这里只有标记
            this.PlayMode++;
            if (this.PlayMode>3){
                this.PlayMode = 1;
            }
            switch (this.PlayMode){
                case 1:
                    imageView5.setImage(new Image("image/随机播放.png"));
                    break;
                case 2:
                    imageView5.setImage(new Image("image/循环播放.png"));
                    break;
                case 3:
                    imageView5.setImage(new Image("image/单曲循环.png"));
                    break;
            }
        });

        ImageView imageView = new ImageView("image/add_white.png");
        imageView.setFitWidth(20);
        imageView.setPreserveRatio(true);
        Label labelAdd = new Label("",imageView);
        labelAdd.setMinHeight(0);
        labelAdd.setMinWidth(0);
        labelAdd.setPrefWidth(20);
        labelAdd.setPrefHeight(20);
        labelAdd.setPadding(new Insets(30,0,0,0));
        labelAdd.setOnMouseEntered(event -> {imageView.setImage(new Image("image/add_black.png"));});
        labelAdd.setOnMouseExited(event -> {imageView.setImage(new Image("image/add_white.png"));});
        labelAdd.setOnMouseClicked(event -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("请选择音乐");
            // 过滤文件
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Mp3","*.mp3"),
                    new FileChooser.ExtensionFilter("flac","*.flac"),
                    new FileChooser.ExtensionFilter("所有文件","*.*"));
            List<File> files = fileChooser.showOpenMultipleDialog(staticScreen);
            if(files != null && files.size() != 0){
                List<String> sounds = XMLUtils.readAllSoundPath();
                System.out.println(sounds);
                boolean allSucceed = true;
                for (File file : files){
                    if (!sounds.contains(file.getPath())){
                        XMLUtils.insertSounds(file);
                        addASound(new ASound(file));
                    }else {
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setTitle("失败！");
                        alert.setHeaderText(file.getName() + "已存在");
                        alert.showAndWait();
                        allSucceed = false;
                    }
                }
                if (allSucceed){
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("成功！");
                    alert.setHeaderText("音乐添加成功");
                    alert.showAndWait();

                }

            }
        });

        HBox hBox1 = new HBox(30);
        hBox1.setPrefWidth(260);
        hBox1.setPadding(new Insets(10,10,10,20));
        hBox1.getChildren().addAll(label1,labelPlay,label3,label6,labelAdd);

        BorderPane bottomPane = new BorderPane();
        bottomPane.setTop(borderPane);
        bottomPane.setBottom(hBox1);

        labelPlayTime.prefHeightProperty().bind(borderPane.prefHeightProperty());
        sliderSong.prefHeightProperty().bind(borderPane.prefHeightProperty());
        labelTotalTime.prefHeightProperty().bind(borderPane.prefHeightProperty());

        return bottomPane;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        staticScreen = primaryStage;

        // 设置舞台
        // 创造一个面板对象
        BorderPane borderPane = new BorderPane();
        // 设置整体的颜色
        borderPane.setBackground(new Background(new BackgroundFill(Color.WHITE,null,null)));
        // 设置各个地方的部件
        borderPane.setTop(getTopPane());
        borderPane.setCenter(getCenterPane());
        borderPane.setBottom(getBottomPane());
        
        // 设置长宽高
        Scene scene = new Scene(borderPane,360,600);// 宽高
        // 将的标题栏去掉
        primaryStage.initStyle(StageStyle.UNDECORATED);
        // 将场景设置到舞台
        primaryStage.setScene(scene);

        // 显示舞台
        primaryStage.show(); //显示舞台 屏幕框框
    }

}
