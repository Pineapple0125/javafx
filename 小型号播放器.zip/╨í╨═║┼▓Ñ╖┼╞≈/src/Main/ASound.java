package Main;

import org.jaudiotagger.audio.exceptions.CannotReadException;
import org.jaudiotagger.audio.exceptions.InvalidAudioFrameException;
import org.jaudiotagger.audio.exceptions.ReadOnlyFileException;
import org.jaudiotagger.audio.mp3.MP3AudioHeader;
import org.jaudiotagger.audio.mp3.MP3File;
import org.jaudiotagger.tag.TagException;

import java.io.File;
import java.io.IOException;
import java.util.Set;

public class ASound {
    public String SoundName;
    public String filePath;
    public String totalStringTime;

    public int totalIntTime;

    public ASound(File file){
        MP3File mp3File;
        try {
            mp3File = new MP3File(file);
            MP3AudioHeader audioHeader = mp3File.getMP3AudioHeader();
            this.totalStringTime = audioHeader.getTrackLengthAsString(); // 获取字符串时间
            this.totalIntTime = audioHeader.getTrackLength();
        } catch (IOException | ReadOnlyFileException | CannotReadException | InvalidAudioFrameException |
                 TagException e) {
            throw new RuntimeException(e);
        }

        this.SoundName = file.getName();
        this.filePath = file.getPath();

    }
}
