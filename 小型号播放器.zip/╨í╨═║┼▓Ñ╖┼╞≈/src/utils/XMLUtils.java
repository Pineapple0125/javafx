package utils;

import Main.ASound;
import Main.MainAPP;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class XMLUtils {


    public static List<String> readAllSoundPath() {
//        创建list集合
        List<String> soundList = new ArrayList<>();
//        创建一个对象
        SAXReader reader = new SAXReader();
//        读取document对象
        try {
            Document document = reader.read(new File("AllXML/MusicGroup.xml"));
//            读取根元素
            Element root = document.getRootElement();
            if (root == null) {
                return soundList;
            } else {
//                读取子元素
                List<Element> groupElementList = root.elements("soundName");
                if (groupElementList == null || groupElementList.size() == 0) {
                    return soundList;
                }

                for (Element sound : groupElementList){
                    soundList.add(sound.elementText("filePath"));
                }
                return soundList;
            }
        } catch (DocumentException e) {
            throw new RuntimeException(e);
        }
    }



    //    添加歌曲到歌单
    public static void insertSounds(File file) {
        SAXReader reader = new SAXReader();
//        读取document对象
        try {
            Document document = reader.read(new File("AllXML/MusicGroup.xml"));
//            读取根元素
            Element root = document.getRootElement();
            List<Element> groupElementList = root.elements("soundName");
            Element soundElement = root.addElement("soundName");
            soundElement.addAttribute("soundName", file.getName());
            Element filePathElement = soundElement.addElement("filePath");
            filePathElement.setText(file.getAbsolutePath());

            OutputFormat outputFormat = OutputFormat.createPrettyPrint();
            outputFormat.setEncoding("UTF-8");
            outputFormat.setExpandEmptyElements(true); //生成一个完整标签
            XMLWriter xmlWriter = new XMLWriter(new FileWriter("AllXML/MusicGroup.xml"), outputFormat);
            xmlWriter.write(document);
            xmlWriter.close();


        } catch (DocumentException | IOException e) {
            throw new RuntimeException(e);
        }

    }

    //  读取歌单内歌曲
    public static List<ASound> readAllSound() {
        List<ASound> soundList = new ArrayList<>();
        SAXReader reader = new SAXReader();
//        读取document对象
        try {
            Document document = reader.read(new File("AllXML/MusicGroup.xml"));
//            读取根元素
            Element root = document.getRootElement();
            List<Element> groupElementList = root.elements("soundName");
            for (Element element : groupElementList) {
                ASound aSound = new ASound(new File(element.elementText("filePath")));
                soundList.add(aSound);
            }

        } catch (DocumentException e) {
            throw new RuntimeException(e);
        }
        return soundList;
    }

    //    删除歌曲
    public static void deleteSound(String soundName){
        SAXReader reader = new SAXReader();
//        读取document对象
        try {
            Document document = reader.read(new File("AllXML/MusicGroup.xml"));
//            读取根元素
            Element root = document.getRootElement();
            List<Element> soundElement = root.elements("soundName");
            for (Element element : soundElement) {
                if (element.attributeValue("soundName").equals(soundName)){
                    root.remove(element);
                }
            }

            OutputFormat outputFormat = OutputFormat.createPrettyPrint();
            outputFormat.setEncoding("UTF-8");
            outputFormat.setExpandEmptyElements(true); //生成一个完整标签
            XMLWriter xmlWriter = new XMLWriter(new FileWriter("AllXML/MusicGroup.xml"), outputFormat);
            xmlWriter.write(document);
            xmlWriter.close();


        } catch (DocumentException | IOException e) {
            throw new RuntimeException(e);
        }

    }


}