package Main_APP.Text;

public class compute_size {
}
