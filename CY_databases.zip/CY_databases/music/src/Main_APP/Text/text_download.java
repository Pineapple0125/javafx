package Main_APP.Text;

import Main_APP.Main.show_song_from_table;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;

public class text_download {

    private static final String  URL="jdbc:mysql://localhost:3306/database_text"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码


    public static void download(String table_name ,String text_name) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL, USER, PASS);
            String sql_2 = "select * from " + table_name + " where text_name = '" + text_name + "'";

            DirectoryChooser directoryChooser = new DirectoryChooser();
            directoryChooser.setTitle("选择文件夹");
            File file = directoryChooser.showDialog(MainText.main_stage);
            String path = file.getPath() + "/"+text_name;
            System.out.println(path);

            try (BufferedOutputStream bop = new BufferedOutputStream(Files.newOutputStream(Paths.get(path)))) {
                PreparedStatement statement_1 = con.prepareStatement(sql_2);
                ResultSet result = statement_1.executeQuery(sql_2);
                while (result.next()) {
                    InputStream inputStream = result.getBinaryStream("text_data");
                    byte[] z = new byte[1024]; // 一次读取1024位数据
                    while (inputStream.read(z) != -1) { // 终止条件 如果因为流位于文件末尾而没有可用的字节，则返回值 -1
                        bop.write(z);
                    }
                }
                statement_1.close();
                con.close();
            } catch (IOException | SQLException e) {
                throw new RuntimeException(e);
            }
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();

        }

    }
}