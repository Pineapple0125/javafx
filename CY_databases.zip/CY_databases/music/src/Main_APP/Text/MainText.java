package Main_APP.Text;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.*;
import java.util.List;

public class MainText {

    public static Stage main_stage = new Stage();

    private static double reSet_X;
    private static double reSet_Y;
    private static double reSet_W;
    private static double reSet_H;
    private static double mouse_X;
    private static double mouse_Y;
    private static Label information; // 这个是目录返回的内容
    private static Label name = new Label("(暂无记录)"); //这个是屏幕上显示的目录名
    private static String catalogue_name;

    private static Label catalogue_introduction = new Label(); //这个是目录的介绍

    private static TableView<table_colum> tableView;
    public static void start() {



        BorderPane borderPane = new BorderPane();
        borderPane.setStyle("\n" +
                " -fx-background-radius: 3px;\n" +
                " -fx-border-color:#FFB90F;\n" +
                " -fx-border-width:3px;\n" +
                " -fx-border-radius:3px; ");
        // 设置整体的颜色
        borderPane.setBackground(new Background(new BackgroundFill(Color.WHITE,null,null)));

        borderPane.setTop(getTopPane());
        borderPane.setLeft(getLeftPane());
        borderPane.setCenter(getCenterPane());


        Scene scene = new Scene(borderPane,1200,800);// 宽高

        // 将的标题栏去掉
        main_stage.initStyle(StageStyle.UNDECORATED);
        // 将场景设置到舞台
        main_stage.setScene(scene);
        // 显示舞台
        main_stage.hide(); //显示舞台 屏幕框框

        

    }


    private static void readAllTextByGroup(ArrayList<List<String>> content){  // 目录内所有文件
        tableView.getItems().clear();
        List<table_colum> table_rows = new ArrayList<>();
        for(List<String> i : content){
            table_colum row = new table_colum();

            row.setText_name(i.get(0).substring(0,i.get(0).indexOf(".")));
            row.setAuthor(i.get(1));
            row.setText_type(i.get(2));
            row.setPeriodical(i.get(3));

            ImageView delete = new ImageView("image/download_dark.png");
            delete.setFitWidth(18);
            delete.setFitHeight(18);
            Label label_Download = new Label("", delete);
            label_Download.setOnMouseEntered(event -> delete.setImage(new Image("image/download_highlight.png")));
            label_Download.setOnMouseExited(event -> delete.setImage(new Image("image/download_dark.png")));

            label_Download.setOnMouseClicked(event -> {
                System.out.println(catalogue_name);
                text_download.download(catalogue_name,row.getText_name());
            });

            label_Download.setAlignment(Pos.CENTER);
            row.setOperation(label_Download);
            table_rows.add(row);
        }
        ObservableList<table_colum> data = FXCollections.observableList(table_rows);
        tableView.setItems(data);
    }

    private static BorderPane getCenterPane(){

        Label alert = new Label("曲录名:");
        alert.setAlignment(Pos.CENTER);
        alert.setMinHeight(30);
        alert.setMinWidth(50);
        alert.setStyle("-fx-border-width: 2;" + "-fx-border-color: rgb(139, 105, 16);" + "-fx-text-fill: rgb(139, 105, 16)");

        name.setMinWidth(60);
        name.setMinHeight(30);
        name.setStyle("-fx-background-color: #FFB90F;" +
                "-fx-background-radius: 15;"+
                "-fx-border-color: white;"+
                "-fx-border-radius: 15;"+
                "-fx-text-fill: white"
        );
        name.setAlignment(Pos.CENTER);

        name.setOnMouseClicked(event -> {
            if (catalogue_name != null) {
                text_upload.upload(catalogue_name);
            }
        });

        HBox nameHBox = new HBox(10);
        nameHBox.getChildren().addAll(alert, name);

        nameHBox.setPadding(new Insets(0,0,120,30));


        Label alert_1 = new Label("曲录介绍:");
        alert_1.setMinHeight(30);
        alert_1.setMinWidth(50);
        alert_1.setTextFill(Color.rgb(139, 105, 16));        // 设置颜色和字体
        alert_1.setFont(new Font("宋体",20));

        catalogue_introduction.setMinWidth(150);
        catalogue_introduction.setPrefWidth(150);
        catalogue_introduction.setPrefHeight(60);

        VBox vBox_left = new VBox(10);
        vBox_left.getChildren().addAll(nameHBox, alert_1 ,catalogue_introduction);


        Label alert_2 = new Label("文案介绍:");
        alert_2.setTextFill(Color.rgb(139, 105, 20));        // 设置颜色和字体
        alert_2.setFont(new Font("宋体",20));
        alert_2.setMinHeight(30);
        alert_2.setMinWidth(100);



        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setPrefHeight(200);
        scrollPane.setPrefWidth(300);
        scrollPane.setMaxHeight(260);
        scrollPane.setMinWidth(600);
        scrollPane.setStyle("-fx-background-color: black");

        information = new Label();
        information.setPadding(new Insets(10,10,10,10));
//        information.setPrefHeight(500);
        information.setMaxWidth(300);

        scrollPane.setContent(information);
        scrollPane.setStyle(
                "-fx-padding: 0;"+
                "-fx-background-insets: 0;"+
                "-fx-border-color: #FFB90F;"+
                "-fx-border-width: 1;"+
                "-fx-border-radius: 15"
        );
        scrollPane.getStylesheets().add("css/text_slide.css");


        VBox vBox_right = new VBox(10);
        vBox_right.getChildren().addAll(alert_2,scrollPane);




        HBox hBox = new HBox(50);
        hBox.setPadding(new Insets(20,20,20,30));
        hBox.getChildren().addAll(vBox_left, vBox_right);
        hBox.setStyle("-fx-border-color: #FFB90F;"+"-fx-border-width: 1;");

        tableView = new TableView<>();
        tableView.setPrefWidth(1060);
        tableView.getStylesheets().add("css/main_list.css");

        TableColumn c1 = new TableColumn("文件名");
        c1.setPrefWidth(150);
        c1.setCellValueFactory(new PropertyValueFactory<>("text_name"));

        TableColumn c2 = new TableColumn("作者");
        c2.setPrefWidth(150);
        c2.setCellValueFactory(new PropertyValueFactory<>("author"));

        TableColumn c3 = new TableColumn("曲种");
        c3.setPrefWidth(150);
        c3.setCellValueFactory(new PropertyValueFactory<>("text_type"));

        TableColumn c4 = new TableColumn("期刊");
        c4.setPrefWidth(150);
        c4.setCellValueFactory(new PropertyValueFactory<>("periodical"));

//        TableColumn c5 = new TableColumn("大小");
//        c5.setPrefWidth(150);
//        c5.setCellValueFactory(new PropertyValueFactory<>("size"));

        TableColumn c5 = new TableColumn("下载");
        c5.setPrefWidth(150);
        c5.setCellValueFactory(new PropertyValueFactory<>("operation"));

        tableView.getColumns().addAll(c1,c2,c3,c4,c5);


        tableView.setRowFactory(tv ->{
            TableRow<table_colum> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if(event.getClickCount() == 2 && !row.isEmpty()) {
                    information.setText(upload_information_by_text.upload(catalogue_name, row.getIndex()+1));
                }
            });
            return row;
        });





        BorderPane centerPane = new BorderPane();
        centerPane.setTop(hBox);
        centerPane.setCenter(tableView);

        return centerPane;
    }

    private static BorderPane getTopPane(){
        ImageView imageView = new ImageView("image/Logo.png");
        imageView.setFitWidth(40);// 设置图片的高度
        imageView.setPreserveRatio(true);//保持比例


        HBox hBox = new HBox(20);
        hBox.setAlignment(Pos.CENTER_LEFT);// 设置向左对其
        hBox.setMaxWidth(50);
        hBox.setMaxHeight(50);
        hBox.setPadding(new Insets(10,0,10,30)); //设置这个box和外界的间隔
        hBox.getChildren().addAll(imageView);



        //      搜索栏
        TextField search = new  TextField();
        search.setPromptText("anything");
        search.setPrefWidth(200);
        search.setPrefHeight(15);
        search.setMaxHeight(15);
        search.setMaxWidth(200);
//        放大镜图标
        ImageView big_mirror = new ImageView("image/max_mirror.png");
        big_mirror.setFitHeight(30);
        big_mirror.setFitHeight(30);
        Label label_bigger = new Label("",big_mirror);
        label_bigger.setMinWidth(0);
        label_bigger.setMinHeight(0);
        label_bigger.setPrefHeight(30);
        label_bigger.setPrefWidth(30);
        label_bigger.setOnMouseClicked(event -> {
            if (search.getText() != null){
                System.out.println(search.getText());
                ArrayList<List<String>> content =  Main_APP.Text.search.research(search.getText());
                readAllTextByGroup(content);
            }
        });

        HBox hBox_center = new HBox(10);
        hBox_center.setPadding(new Insets(10,30,10,0));
        hBox_center.setAlignment(Pos.CENTER);
        hBox_center.setPrefWidth(250);
        hBox_center.setPrefHeight(30);
        hBox_center.getChildren().addAll(label_bigger,search);
        hBox_center.setPadding(new Insets(0,0,0,40));



        // 设置右侧的那几个按钮
        // 最大化按钮
        ImageView max = new ImageView("image/minimal.png");
        max.setFitWidth(30);
        max.setFitHeight(30);

        Label label = new Label("",max);
        label.setMinWidth(0);
        label.setMinHeight(0);
        label.setPrefHeight(30);
        label.setPrefWidth(30);

        label.setOnMouseEntered(event -> max.setImage(new Image("image/Maximal.png")));
        label.setOnMouseExited(event -> max.setImage(new Image("image/minimal.png")));
        // 最大化 需要判定窗体的状态
        label.setOnMouseClicked(event -> {
            if(!main_stage.isMaximized()){
//                记录信息
                reSet_X = main_stage.getX();
                reSet_Y = main_stage.getY();
                reSet_H = main_stage.getHeight();
                reSet_W = main_stage.getWidth();
                main_stage.setMaximized(true);
            }else {
                main_stage.setMaximized(false);
                main_stage.setX(reSet_X);
                main_stage.setY(reSet_Y);
                main_stage.setHeight(reSet_H);
                main_stage.setWidth(reSet_W);

            }
        });

//        最小化按钮
        ImageView min = new ImageView("image/while__.png");
        min.setFitWidth(30);
        min.setFitHeight(30);

        Label label1 = new Label("",min);
        label1.setMinWidth(0);
        label1.setMinHeight(0);
        label1.setPrefHeight(30);
        label1.setPrefWidth(30);

        label1.setOnMouseEntered(event -> min.setImage(new Image("image/black__.png")));
        label1.setOnMouseExited(event -> min.setImage(new Image("image/while__.png")));
        // 鼠标点击
        label1.setOnMouseClicked(event -> main_stage.setIconified(true));

//        关闭按钮
        ImageView close = new ImageView("image/black_X.png");
        close.setFitWidth(30);
        close.setFitHeight(30);

        Label label2 = new Label("",close);
        label2.setMinWidth(0);
        label2.setMinHeight(0);
        label2.setPrefHeight(30);
        label2.setPrefWidth(30);

        label2.setOnMouseEntered(event -> close.setImage(new Image("image/red_X.png")));
        label2.setOnMouseExited(event -> close.setImage(new Image("image/black_X.png")));
        label2.setOnMouseClicked(event -> main_stage.hide());

        HBox hBox1 = new HBox(20); //内部元素之间的间距为10
        hBox1.setPadding(new Insets(10,30,10,0));
        hBox1.setAlignment(Pos.CENTER_LEFT);
        hBox1.setPrefWidth(150);
        hBox1.setPrefHeight(50);
        hBox1.getChildren().addAll(label1,label,label2);

        // 设置一个装饰用的紫线
        Rectangle rect = new Rectangle();
        rect.setX(0);
        rect.setY(0);
        rect.setWidth(100);
        rect.setHeight(10);
        // 设置背景色 渐变 stop 表示梯度
        Stop[] stops =new Stop[]{
                new Stop(0,Color.rgb(205, 149, 12)),
                new Stop(0.5,Color.rgb(238, 173, 14)),
                new Stop(1,Color.rgb(255, 185, 15))
        }; // 一个渐变的操作
        rect.setFill(new LinearGradient(0,0,1,1,true, CycleMethod.NO_CYCLE,stops));

        BorderPane topPane = new BorderPane();
        topPane.setBottom(rect); // 设置到底部了
        topPane.setLeft(hBox);
        topPane.setCenter(hBox_center);
        topPane.setRight(hBox1);
        topPane.setStyle("-fx-background-color: rgb(255, 193, 37);");

        //将红线的宽度和屏幕保持一致
        rect.widthProperty().bind(main_stage.widthProperty());


        // 设置 拖拽功能
        topPane.setOnMousePressed(event -> { // 鼠标点击
            // 记录鼠标相对于窗口的坐标x，y
            mouse_X = event.getSceneX();
            mouse_Y = event.getSceneY();

        });
        topPane.setOnMouseDragged(event -> {
            main_stage.setX(event.getScreenX()-mouse_X);
            main_stage.setY(event.getScreenY()-mouse_Y);
        });


        return topPane;
    }

    private static BorderPane getLeftPane(){
        ImageView image_1 = new ImageView("image/Logo.png");
        image_1.setFitWidth(260);
        image_1.setPreserveRatio(true); // 设置等比例

        // 作者名字
        Label labelAuthor = new Label("潮乐数据盒");
        labelAuthor.setPrefWidth(260);
        labelAuthor.setTextFill(Color.rgb(139, 105, 20));        // 设置颜色和字体
        labelAuthor.setFont(new Font("宋体",20));
        labelAuthor.setAlignment(Pos.CENTER);

        Label label_version = new Label("version:0.0.1");
        label_version.setPrefWidth(260);
        label_version.setFont(new Font("宋体",20));
        label_version.setAlignment(Pos.CENTER);
        label_version.setTextFill(Color.rgb(139, 105, 20));

        Label text_table = new Label("文案列表");
        text_table.setPrefWidth(240);
        text_table.setPrefHeight(30);
        text_table.setTextFill(Color.rgb(139, 105, 20));
        

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setMaxHeight(320);
        scrollPane.setPrefWidth(260);
        scrollPane.getStylesheets().add("css/text_slide.css");
        scrollPane.setStyle(
                "-fx-padding: 0;"+
                "-fx-background-insets: 0;"
        );


        VBox vBoxCatalogue = new VBox(5);

        for (String i :text_list.read_text_group()) {
            Label catalogue = new Label("    "+i);
            catalogue.setMinHeight(30);
            catalogue.setMinWidth(208);
            catalogue.setStyle(
                 "-fx-background-color: white;"+
                 "-fx-background-radius: 30;"+
                 "-fx-border-style: solid;" +
                 "-fx-border-color: #FFB90F;" +
                 " -fx-border-width: 0.5;"+
                 "-fx-border-radius: 30;"
            );

            catalogue.setOnMouseEntered(event -> {
                catalogue.setStyle(
                    "-fx-background-color: #FFB90F;"+
                    "-fx-text-fill: white;"+
                    "-fx-background-radius: 30;"+
                    "-fx-border-style: solid;" +
                    "-fx-border-color: #FFB90F;" +
                    " -fx-border-width: 0.5;"+
                    "-fx-border-radius: 30;"
                );
            });
            catalogue.setOnMouseExited(event -> {
                catalogue.setStyle(
                     "-fx-background-color: white;"+
                     "-fx-background-radius: 30;"+
                     "-fx-border-style: solid;" +
                     "-fx-border-color: #FFB90F;" +
                     " -fx-border-width: 0.5;"+
                     "-fx-border-radius: 30;"
                );
            });

            catalogue.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2){
                    ArrayList<List<String>> content = text_read.read_content(i);
                    catalogue_introduction.setText(upload_catalogue.upload(i));
                    catalogue_name = i;

                    name.setText(i);
                    readAllTextByGroup(content);
                }
            });

            vBoxCatalogue.getChildren().add(catalogue);
        }
        scrollPane.setContent(vBoxCatalogue);

        VBox vBoxSlide = new VBox();
        vBoxSlide.setPadding(new Insets(5,5,5,10));
        vBoxSlide.getChildren().add(scrollPane);

        VBox vBox = new VBox(15); // 这里是间距
        vBox.setPadding(new Insets(5,5,5,10));
        vBox.getChildren().addAll(image_1, labelAuthor, label_version, text_table);


        BorderPane LeftPane = new BorderPane();
        LeftPane.setTop(vBox);
        LeftPane.setCenter(vBoxSlide);
        return LeftPane;
    }



}
