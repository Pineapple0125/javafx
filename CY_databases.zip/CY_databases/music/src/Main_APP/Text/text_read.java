package Main_APP.Text;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class text_read {

    private static final String  URL="jdbc:mysql://localhost:3306/database_text"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public static ArrayList<List<String>> read_content(String catalogue_name){
        ArrayList<List<String>> content = new ArrayList<List<String>>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql_1 = "select * from "+catalogue_name+";";
            PreparedStatement doing = con.prepareStatement(sql_1);
            ResultSet result = doing.executeQuery();

            while (result.next()){
                ArrayList<String> temp = new ArrayList<>();
                temp.add(result.getString("text_name"));
                temp.add(result.getString("author"));
                temp.add(result.getString("text_type"));
                temp.add(result.getString("periodical"));
                content.add(temp);
            }
            doing.close();
            con.close();
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return content;

    }
}
