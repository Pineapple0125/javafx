package Main_APP.Text;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Scanner;

public class text_upload {

    private static final String  URL="jdbc:mysql://localhost:3306/database_text"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public static void upload(String table_name){

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("请选择音乐");
        File file = fileChooser.showOpenDialog(MainText.main_stage);

        try{
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql0 = "select text_name from "+table_name+ " where text_name = '"+file.getName()+"';";
//                这里是先搜索看看原歌单里存不存在这首歌 不存在就添加
            System.out.println(table_name);
            System.out.println(file.getName());
            PreparedStatement statement_0=con.prepareStatement(sql0); //create接口
            ResultSet resultSet = statement_0.executeQuery(sql0);
            if (!resultSet.next()){
                FileInputStream song_byte = new FileInputStream(file);
                String sql="insert into "+table_name+"(text_name, author, text_type ,periodical ,text_data) values(?,?,?,?,?);"; //MySQL语句插入


                PreparedStatement statement_1=con.prepareStatement(sql); //create接口
                statement_1.setString(1, file.getName());
                System.out.println("请输入作者");
                statement_1.setString(2, new Scanner(System.in).next());
                System.out.println("请输入曲类");
                statement_1.setString(3, new Scanner(System.in).next());
                System.out.println("请输入期刊");
                statement_1.setString(4, new Scanner(System.in).next());
                statement_1.setBinaryStream(5, song_byte, ((InputStream) song_byte).available()); // 第二个空填的东西


                statement_1.execute();
                con.close();
                statement_0.close();
                statement_1.close();
                System.out.println("succeed");

            }

        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException | IOException e) {
            throw new RuntimeException(e);
        }
    }
}
