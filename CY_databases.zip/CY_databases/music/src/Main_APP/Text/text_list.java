package Main_APP.Text;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class text_list {

    private static final String  URL="jdbc:mysql://localhost:3306/database_text"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public static List<String> read_text_group(){
        List<String> groupList = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = (Connection) DriverManager.getConnection(URL,USER,PASS);
            String sql_1 = "select table_name from information_schema.tables where (table_schema = 'database_text' and table_name != 'introduction');";
            PreparedStatement doing = con.prepareStatement(sql_1);
            ResultSet result = doing.executeQuery();
            while (result.next()){
                String pic_name = result.getString("table_name");
                groupList.add(pic_name);
            }
            doing.close();
            con.close();
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return groupList;

    }
}
