package Main_APP.Text;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class search {

    private static final String  URL="jdbc:mysql://localhost:3306/database_text"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public static ArrayList<List<String>> research(String content){
        try {
            ArrayList<List<String>> list = new ArrayList<List<String>>();
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql_1 = "select table_name from information_schema.tables where table_schema='database_text' and table_name != 'introduction'";
            PreparedStatement doing_1 = con.prepareStatement(sql_1);
            ResultSet result_1 = doing_1.executeQuery();
            while (result_1.next()){
                String sql_2 = "select * from "+result_1.getString("table_name")+" where (text_name like '%"+content+"%' or author like '%"+content+"%' or text_type like '%"+content+"%' or periodical like '%"+content+"%');";
                PreparedStatement doing_2 = con.prepareStatement(sql_2);
                ResultSet result_2 = doing_2.executeQuery();
                while (result_2.next()){
                    ArrayList<String> temp = new ArrayList<>();
                    temp.add(result_2.getString("text_name"));
                    temp.add(result_2.getString("author"));
                    temp.add(result_2.getString("text_type"));
                    temp.add(result_2.getString("periodical"));
                    list.add(temp);
                }
                doing_2.close();
                result_2.close();
            }
        doing_1.close();
        result_1.close();
        con.close();
        return list;
    } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
