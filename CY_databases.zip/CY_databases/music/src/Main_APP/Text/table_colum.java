package Main_APP.Text;

import javafx.scene.control.Label;

public class table_colum {


    private String text_name;
    private String  author;
    private String text_type;
    private String periodical;
//    private String size;
    private Label operation;

    public String getText_name() {
        return text_name;
    }

    public void setText_name(String text_name) {
        this.text_name = text_name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getText_type() {
        return text_type;
    }

    public void setText_type(String text_type) {
        this.text_type = text_type;
    }

    public String getPeriodical() {
        return periodical;
    }

    public void setPeriodical(String periodical) {
        this.periodical = periodical;
    }

//    public String getSize() {
//        return size;
//    }

//    public void setSize(String size) {
//        this.size = size;
//    }

    public Label getOperation() {
        return operation;
    }

    public void setOperation(Label operation) {
        this.operation = operation;
    }

}
