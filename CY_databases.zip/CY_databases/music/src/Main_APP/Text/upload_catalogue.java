package Main_APP.Text;

import java.sql.*;

public class upload_catalogue {

    private static final String  URL="jdbc:mysql://localhost:3306/database_text"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public static String upload(String table_name){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql = "select information from introduction where catalogue_name = '"+table_name+"';";
            PreparedStatement statement_0=con.prepareStatement(sql); //create接口
            ResultSet resultSet = statement_0.executeQuery(sql);
            if (resultSet.next()){
                String result = resultSet.getString("information");
                System.out.println(result);
                con.close();
                statement_0.close();
                return result;

            }

        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return "暂无介绍 双击获取文章摘要";
    }
}
