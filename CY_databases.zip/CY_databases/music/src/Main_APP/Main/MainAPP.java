package Main_APP.Main;

import Main_APP.Text.MainText;



import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.lang.Exception;
import java.net.URI;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.util.List;

import javafx.scene.layout.StackPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.jaudiotagger.audio.exceptions.CannotReadException;
import org.jaudiotagger.audio.exceptions.InvalidAudioFrameException;
import org.jaudiotagger.audio.exceptions.ReadOnlyFileException;
import org.jaudiotagger.audio.mp3.MP3AudioHeader;
import org.jaudiotagger.audio.mp3.MP3File;
import org.jaudiotagger.tag.TagException;
import org.jaudiotagger.tag.id3.AbstractID3v2Frame;
import org.jaudiotagger.tag.id3.AbstractID3v2Tag;
import org.jaudiotagger.tag.id3.framebody.FrameBodyAPIC;
import utils.ImageUtils;

import javax.swing.*;


public class MainAPP extends Application {
    // 为了让按钮可以控制屏幕 需要一个全局的屏幕
    public static Stage staticScreen;
    // 记录最大化之前的屏幕信息
    private double reSet_X;
    private double reSet_Y;
    private double reSet_W;
    private double reSet_H;
    //记录鼠标拖拽操作 相对于页面的坐标
    private double mouse_X;
    private double mouse_Y;

    private VBox vBox1;

    private String song_table;

    private String song_of_playing;
    //歌单名称标签
    private Label labelGroupName;

    //播放列表的table
    private TableView<PlayBean> tableView;

    // 当前播放歌曲的索引
    private int currentIndex;

    //当前播放时间的前一秒 -- 设置滚动条
    private int preSecond;
    //当前的playBean
    private PlayBean currentPlayBean;
    // 总时间
    private Label labelTotalTime;
    //已经播放的时间
    private Label labelPlayTime;
    //碟片
    private ImageView panImageview;
    // 转圈圈的
    private Timeline timeline;
    // 背景
    private ImageView backImageView;
    //播放按钮
    private ImageView buttonPlayImage;
    private Label labelPlay;

    private  int PlayMode = 1; // 列表循环 随机播放 单曲循环

    private Slider sliderSong; //播放时间滚动条对象
    private Slider sliderVolume; // 音量条子

    private ProgressBar volumeProgress; //音量的进度条

    private double prevVolume; //记录原来的音量

    private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    private Stage stage;

    private List<HBox> hBoxList;

    private void readAllSoundByGroup(){  // 歌单内的全部歌曲
        List<show_song_from_table> list = show_song_from_table.ADD(this.labelGroupName.getText().trim());
        // 解析每个歌曲文件 封装 playbean
        List<PlayBean> playBeansList = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            show_song_from_table show_song_from_table = list.get(i);
            PlayBean playBean = new PlayBean();
            playBean.setId(i+1);
//            读取音频文件
            File file = new File(show_song_from_table.getFilepath());
            MP3File mp3File = null;
            try {
                mp3File = new MP3File(file);
            } catch (IOException | ReadOnlyFileException | CannotReadException | InvalidAudioFrameException |
                     TagException e) {
                throw new RuntimeException(e);
            }
//            获取mp3文件信息
            MP3AudioHeader audioHeader = (MP3AudioHeader) mp3File.getMP3AudioHeader();
            String strLength = audioHeader.getTrackLengthAsString(); // 获取时间
            int intLength = audioHeader.getTrackLength();
            Set<String> keySet = mp3File.getID3v2Tag().frameMap.keySet();
            String songName = show_song_from_table.fileName;
            String artist = null;
            String album = null;
//            String soundType = null;

//            if (keySet.contains("TIT2")){ // 歌名标记
//                songName = mp3File.getID3v2Tag().frameMap.get("TIT2").toString();
//            }
            if (keySet.contains("TPE1")){ // 演唱者
                artist = mp3File.getID3v2Tag().frameMap.get("TPE1").toString();
            }
            if (keySet.contains("TALB")){ // 专辑名 从mp3内取出
                album = mp3File.getID3v2Tag().frameMap.get("TALB").toString();
            }
            System.out.println("歌名"+songName+artist+album);

            // 去除名字前后的双引号
//            if(songName != null && !songName.equals("null")){

//            }

            if(artist != null && !artist.equals("null")){
                artist = artist.substring(artist.indexOf("\"")+1,artist.lastIndexOf("\""));
            } else  {
                String temp = get_data.get_artist(songName);
                if (temp != null){
                    artist = temp;
                }
            }

            if(album != null && !album.equals("null")){
                album = album.substring(album.indexOf("\"")+1,album.lastIndexOf("\""));
            }else  {
                String temp = get_data.get_album(songName);
                System.out.println(temp);
                if (temp != null){
                    album = temp;
                }
            }

            songName = songName.substring(0,songName.lastIndexOf("."));

            playBean.setSoundName(songName);
            playBean.setArtist(artist);
            playBean.setAlbum(album);
            playBean.setFilePath(show_song_from_table.getFilepath());
            System.out.println(labelGroupName.getText() +"   "+ songName+".mp3");
            playBean.setSoundType(labelGroupName.getText(),songName+".mp3");
//            soundType = playBean.getSoundType();

            System.out.println(labelGroupName.getText());
            URI uri = file.toURI(); // 获取本地uri对象
            Media media = new Media(uri.toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);

            //监听 播放器播放时的事件
            mediaPlayer.currentTimeProperty().addListener(new ChangeListener<Duration>() {
                @Override
                public void changed(ObservableValue<? extends Duration> observable,
                                    Duration oldValue, Duration newValue) {
                                   // 播放前后的时间
                    // 每秒动一下 用秒操作
                    int currentSecond = (int) newValue.toSeconds();

                    // 设置滚动条 一秒一次
                    if(currentSecond == preSecond + 1){
                        // 设置滚动条
                        sliderSong.setValue(sliderSong.getValue()+1);
                        // 设置前一秒
                        preSecond++;
                        // 设置新的播放时间
                        Date date = new Date();
                        date.setTime((int)sliderSong.getValue()*1000);
                        labelPlayTime.setText(new SimpleDateFormat("mm:ss").format(date));

                    }
                }
            });

            // 监听播放完毕时
            mediaPlayer.setOnEndOfMedia(()->{
                // 停止播放器
                this.currentPlayBean.getMediaPlayer().stop();
                // 停止光盘的转动
                this.timeline.stop();
                // 根据当前播放模式选择下一首
                switch (this.PlayMode){
                    case 1: // 循环播放
                        Random random = new Random();
                        int number = random.nextInt(tableView.getItems().size());
                        this.currentIndex += number;
                        if (this.currentIndex >= this.tableView.getItems().size()){
                            currentIndex %= number;
                        }
                        this.currentPlayBean = tableView.getItems().get(this.currentIndex);
                        break;
                    case 2: // 列表乱循序播放
                        this.currentIndex++;
                        if (this.currentIndex >= this.tableView.getItems().size()){
                            this.currentIndex = 0;
                        }
                        this.currentPlayBean = tableView.getItems().get(this.currentIndex);
                        break;
                    case 3: // 单曲循环
                        this.currentPlayBean.getMediaPlayer().seek(new Duration(0));
                        break;
                }
                this.tableView.getSelectionModel().select(currentIndex);
                play();
            });

            playBean.setMediaPlayer(mediaPlayer);

            BigDecimal bigDecimal = new BigDecimal(file.length()); // 计算文件大小
            BigDecimal result = bigDecimal.divide(new BigDecimal(1024*1024),2, RoundingMode.HALF_UP); // 边mb 四舍五入 保留两位小数
            playBean.setLength(result.toString()+"MB");
            playBean.setTime(strLength); // 字符串时间
            playBean.setTotalSeconds(intLength); // 总的秒数

            ImageView iv_Delete = new ImageView("image/LajiTong.png");
            iv_Delete.setFitWidth(18);
            iv_Delete.setFitHeight(18);

            Label labelDelete = new Label("",iv_Delete);
            labelDelete.setOnMouseEntered(event -> iv_Delete.setImage(new Image("image/LajiTong_highlight.png")));
            labelDelete.setOnMouseExited(event -> iv_Delete.setImage(new Image("image/LajiTong.png")));
            labelDelete.setOnMouseClicked(event -> {
                System.out.println(playBean.getSoundName());
                delete_sound.delete(playBean.getSoundName()+".mp3",labelGroupName.getText());
                if (currentIndex == playBean.getId()-1 && this.currentPlayBean != null){
                    if(tableView.getItems().size() == 1){
                        this.currentPlayBean.getMediaPlayer().stop();
                        this.tableView.getSelectionModel().select(null);
                    }else {
                    currentIndex = 0;
                    this.currentPlayBean.getMediaPlayer().stop();
                    this.tableView.getSelectionModel().select(this.currentIndex);
                    this.currentPlayBean = tableView.getItems().get(this.currentIndex);
                    play();
                    }
                }

                playBeansList.remove(playBean);
            });
            labelDelete.setAlignment(Pos.CENTER);
            playBean.setLabDelete(labelDelete);

            //设置图像 获取图片流
            AbstractID3v2Tag tag = mp3File.getID3v2Tag();
            AbstractID3v2Frame frame = (AbstractID3v2Frame) tag.getFrame("APIC");
            if(frame != null){
                FrameBodyAPIC body = (FrameBodyAPIC) frame.getBody();
                byte [] imageData = body.getImageData();
                // 将图片流转化为image对象
                java.awt.Image image = Toolkit.getDefaultToolkit().createImage(imageData,0,imageData.length);
                BufferedImage bufferedImage = ImageUtils.toBufferedImage(image);
                WritableImage writableImage = SwingFXUtils.toFXImage(bufferedImage,null);
                playBean.setImage(writableImage);
            }
            // 将playBean 放到list
            playBeansList.add(playBean);
        }
        // 将list显示
        ObservableList<PlayBean> data = FXCollections.observableList(playBeansList);
        this.tableView.getItems().clear(); // 先清空
        this.tableView.setItems(data);
    }

    private void readLimitSound(String key){
        labelGroupName.setText(" ");
        List<search_song> list = search_song.Search(key);
        // 解析每个歌曲文件 封装playbean
        List<PlayBean> playBeansList = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            search_song show_song_from_table = list.get(i);
            PlayBean playBean = new PlayBean();
            playBean.setId(i+1);
//            读取音频文件
            File file = new File(show_song_from_table.getFilepath());
            MP3File mp3File = null;
            try {
                mp3File = new MP3File(file);
            } catch (IOException | ReadOnlyFileException | CannotReadException | InvalidAudioFrameException |
                     TagException e) {
                throw new RuntimeException(e);
            }
//            获取mp3文件信息
            MP3AudioHeader audioHeader = (MP3AudioHeader) mp3File.getMP3AudioHeader();
            String strLength = audioHeader.getTrackLengthAsString(); // 获取时间
            int intLength = audioHeader.getTrackLength();
            Set<String> keySet = mp3File.getID3v2Tag().frameMap.keySet();
            String songName = show_song_from_table.fileName;
            String artist = null;
            String album = null;

//            if (keySet.contains("TIT2")){ // 歌名标记
//                songName = mp3File.getID3v2Tag().frameMap.get("TIT2").toString();
//            }
            if (keySet.contains("TPE1")){ // 演唱者
                artist = mp3File.getID3v2Tag().frameMap.get("TPE1").toString();
            }
            if (keySet.contains("TALB")){ // 专辑名 从mp3内取出
                album = mp3File.getID3v2Tag().frameMap.get("TALB").toString();
            }
            System.out.println("歌名"+songName+artist+album);



            if(artist != null && !artist.equals("null")){
                artist = artist.substring(artist.indexOf("\"")+1,artist.lastIndexOf("\""));
            } else  {
                String temp = get_data.get_artist(songName);
                if (temp != null){
                    artist = temp;
                }
            }


            if(album != null && !album.equals("null")){
                album = album.substring(album.indexOf("\"")+1,album.lastIndexOf("\""));
            }else  {
                String temp = get_data.get_album(songName);
                System.out.println(temp);
                if (temp != null){
                    album = temp;
                }
            }


            // 去除名字前后的双引号
            songName = songName.substring(0,songName.lastIndexOf("."));

            playBean.setSoundName(songName);
            playBean.setArtist(artist);
            playBean.setAlbum(album);
            playBean.setFilePath(show_song_from_table.getFilepath());
            playBean.setSoundType("all_music",songName+".mp3");

            URI uri = file.toURI(); // 获取本地uri对象
            Media media = new Media(uri.toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);

            //监听 播放器播放时的事件
            mediaPlayer.currentTimeProperty().addListener(new ChangeListener<Duration>() {
                @Override
                public void changed(ObservableValue<? extends Duration> observable,
                                    Duration oldValue, Duration newValue) {
                    // 播放前后的时间
                    // 每秒动一下 用秒操作
                    int currentSecond = (int) newValue.toSeconds();

                    // 设置滚动条 一秒一次
                    if(currentSecond == preSecond + 1){
                        // 设置滚动条
                        sliderSong.setValue(sliderSong.getValue()+1);
                        // 设置前一秒
                        preSecond++;
                        // 设置新的播放时间
                        Date date = new Date();
                        date.setTime((int)sliderSong.getValue()*1000);
                        labelPlayTime.setText(new SimpleDateFormat("mm:ss").format(date));

                    }
                }
            });

            // 监听播放完毕时
            mediaPlayer.setOnEndOfMedia(()->{
                // 停止播放器
                this.currentPlayBean.getMediaPlayer().stop();
                // 停止光盘的转动
                this.timeline.stop();
                // 根据当前播放模式选择下一首
                switch (this.PlayMode){
                    case 1: // 循环播放
                        Random random = new Random();
                        int number = random.nextInt(tableView.getItems().size());
                        this.currentIndex += number;
                        if (this.currentIndex >= this.tableView.getItems().size()){
                            currentIndex %= number;
                        }
                        this.currentPlayBean = tableView.getItems().get(this.currentIndex);
                        break;
                    case 2: // 列表乱循序播放
                        this.currentIndex++;
                        if (this.currentIndex >= this.tableView.getItems().size()){
                            this.currentIndex = 0;
                        }
                        this.currentPlayBean = tableView.getItems().get(this.currentIndex);
                        break;
                    case 3: // 单曲循环
                        this.currentPlayBean.getMediaPlayer().seek(new Duration(0));
                        break;
                }
                this.tableView.getSelectionModel().select(currentIndex);
                play();
            });

            playBean.setMediaPlayer(mediaPlayer);

            BigDecimal bigDecimal = new BigDecimal(file.length()); // 计算文件大小
            BigDecimal result = bigDecimal.divide(new BigDecimal(1024*1024),2, RoundingMode.HALF_UP); // 边mb 四舍五入 保留两位小数
            playBean.setLength(result.toString()+"MB");
            playBean.setTime(strLength); // 字符串时间
            playBean.setTotalSeconds(intLength); // 总的秒数

            AbstractID3v2Tag tag = mp3File.getID3v2Tag();
            AbstractID3v2Frame frame = (AbstractID3v2Frame) tag.getFrame("APIC");
            if(frame != null){
                FrameBodyAPIC body = (FrameBodyAPIC) frame.getBody();
                byte [] imageData = body.getImageData();
                // 将图片流转化为image对象
                java.awt.Image image = Toolkit.getDefaultToolkit().createImage(imageData,0,imageData.length);
                BufferedImage bufferedImage = ImageUtils.toBufferedImage(image);
                WritableImage writableImage = SwingFXUtils.toFXImage(bufferedImage,null);
                playBean.setImage(writableImage);
            }
            // 将playBean 放到list
            playBeansList.add(playBean);
        }
        // 将list显示
        ObservableList<PlayBean> data = FXCollections.observableList(playBeansList);
        this.tableView.getItems().clear(); // 先清空
        this.tableView.setItems(data);
    }


    @Override
    public void start(Stage primaryStage) throws Exception {
        staticScreen = primaryStage;

        MainText.start();

        // 设置舞台
        // 创造一个面板对象
        BorderPane borderPane = new BorderPane();
        borderPane.setStyle("\n" +
                " -fx-background-radius: 3px;\n" +
                " -fx-border-color:#FFB90F;\n" +
                " -fx-border-width:3px;\n" +
                " -fx-border-radius:3px; ");
        // 设置整体的颜色
        borderPane.setBackground(new Background(new BackgroundFill(Color.WHITE,null,null)));
        // 设置各个地方的部件
        borderPane.setTop(getTopPane());
        borderPane.setLeft(getLeftPane());
        borderPane.setBottom(getBottomPane());
        borderPane.setCenter(getCenterPane());

        // 设置长宽高
        Scene scene = new Scene(borderPane,1200,800);// 宽高
        // 将的标题栏去掉
        primaryStage.initStyle(StageStyle.UNDECORATED);
        // 将场景设置到舞台
        primaryStage.setScene(scene);
        // 显示舞台
        primaryStage.show(); //显示舞台 屏幕框框
    }
    // 中心面板
    private BorderPane getCenterPane() {
        /// 读取上次关闭时的歌单和歌曲
        String []playInfo = null;
        Label label1 = new Label("歌单");
        label1.setTextFill(Color.rgb(205, 173, 0));

        BorderStroke bs = new BorderStroke(
                Color.rgb(238, 180, 34), // 四个边颜色
                Color.rgb(238, 180, 34),
                Color.rgb(238, 180, 34),
                Color.rgb(238, 180, 34),
                BorderStrokeStyle.SOLID, // 四个边实线
                BorderStrokeStyle.SOLID,
                BorderStrokeStyle.SOLID,
                BorderStrokeStyle.SOLID,
                new CornerRadii(1),
                new BorderWidths(1),
                new Insets(1,2,1,2)
        );
        label1.setBorder(new Border(bs));
        label1.setLayoutX(30);
        label1.setLayoutY(10);
        label1.setPrefWidth(50);
        label1.setPrefHeight(25);
        label1.setAlignment(Pos.CENTER);

        labelGroupName = new Label(playInfo == null?"（无记录）":playInfo[0]);
        labelGroupName.setLayoutX(90);
        labelGroupName.setLayoutY(9);
        labelGroupName.setTextFill(Color.rgb(139, 105, 20));
        labelGroupName.setFont(new Font("宋体",18));
        labelGroupName.setPrefHeight(200);
        labelGroupName.setPrefHeight(25);
        labelGroupName.setAlignment(Pos.CENTER_LEFT);

//        碟片
        panImageview = new ImageView("image/pan.png");
        panImageview.setFitHeight(200);
        panImageview.setFitWidth(200);
        Label label2 = new Label("",panImageview);
        label2.setLayoutX(30);
        label2.setLayoutY(60);

        //定义一个圆
        Circle circle = new Circle();
        circle.setCenterX(100);
        circle.setCenterY(100);
        circle.setRadius(100); // 半径
        panImageview.setClip(circle);

        // 定义一个时间轴动画
        timeline = new Timeline();
        timeline.getKeyFrames().addAll(
                new KeyFrame(new Duration(0), // 从0秒开始转
                new KeyValue(panImageview.rotateProperty(),0)),// o角度开始
                new KeyFrame(new Duration(8000),new KeyValue(panImageview.rotateProperty(),360))

        );
        timeline.setCycleCount(Timeline.INDEFINITE); // 无限循环
        timeline.play();

        // 歌词的vbox容器
        VBox lyric_vobx = new VBox(15);
        lyric_vobx.setPadding(new Insets(20,20,20,20));
        lyric_vobx.setLayoutX(250);
        lyric_vobx.setLayoutY(0);

        // 歌单列表标签
        Label label3 = new Label("歌单");
        label3.setFont(new Font("宋体",16));
        label3.setPrefWidth(50);
        label3.setPrefHeight(35);
        label3.setTextFill(Color.WHITE);
        label3.setAlignment(Pos.CENTER);
        label3.setBackground(new Background(new BackgroundFill(Color.rgb(205, 173, 0),null,null)));
        label3.setLayoutX(30);
        label3.setLayoutY(260);

        // 模糊背景
        Image image = new Image("image/pan.png");
        PixelReader pixelReader = image.getPixelReader();
        // 创造一个writable_image // 可写image
        WritableImage writableImage = new WritableImage(
                (int)image.getWidth(),
                (int)image.getHeight()
        );
        // 创造一个像素写入器 在楼上读取像素如何在这里输出
        PixelWriter pixelWriter = writableImage.getPixelWriter();
//         循环读取image中的每个像素
        for (int i = 1; i < (int)image.getHeight()+1; i++) {
        int I =0;
        I+=1;
            for (int j = 1; j < (int)image.getWidth()+1; j++) {
                int J =0;
                J+=1;
                Color color = pixelReader.getColor(I,J);
                 // 淡化颜色
                for (int k = 0; k < 4; k++) { // 淡化四次
                    color = color.darker();
                }
                pixelWriter.setColor(I,J,color);
            }
        }
        backImageView = new ImageView(writableImage);
        backImageView.setLayoutX(0);
        backImageView.setLayoutY(0);
        backImageView.setFitHeight(300);
        backImageView.setFitWidth(300);

        //高斯模糊
        GaussianBlur gaussianBlur = new GaussianBlur();
        gaussianBlur.setRadius(63);

        // 一条橙线
        Label labelLine = new Label();
        labelLine.setMinHeight(0);
        labelLine.prefHeight(2);
        labelLine.setBackground(new Background(new BackgroundFill(Color.rgb(255, 215, 0),null,null)));
        labelLine.setLayoutX(0);
        labelLine.setLayoutY(label3.getLayoutY() + label3.getPrefHeight());


        // 滚动条 小面板
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.getChildren().addAll(backImageView,label1,labelGroupName,label2,lyric_vobx,label3,labelLine);
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(anchorPane);
        scrollPane.setPrefHeight(304);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setPadding(new Insets(0,0,0,0));
        scrollPane.setBorder(new Border(bs));
        scrollPane.setStyle(
                "-fx-padding: 0;"+
                "-fx-background-insets: 0;");
        anchorPane.prefWidthProperty().bind(scrollPane.widthProperty());
        anchorPane.prefHeightProperty().bind(scrollPane.heightProperty());
        backImageView.fitHeightProperty().bind(scrollPane.heightProperty());
        backImageView.fitWidthProperty().bind(scrollPane.widthProperty());
        labelLine.prefWidthProperty().bind(scrollPane.widthProperty());

//***********************borderPane 总的************************
        //********************* 歌单列表
        tableView = new TableView<>();
        tableView.setPrefWidth(1060);
        tableView.getStylesheets().add("css/main_list.css");

        TableColumn c1 = new TableColumn("序号");
        c1.setPrefWidth(40);
        c1.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn c2 = new TableColumn("音乐标题");
        c2.setPrefWidth(300);
        c2.setCellValueFactory(new PropertyValueFactory<>("soundName"));

        TableColumn c3 = new TableColumn("歌手");
        c3.setPrefWidth(150);
        c3.setCellValueFactory(new PropertyValueFactory<>("artist"));

        TableColumn c4 = new TableColumn("专辑");
        c4.setPrefWidth(150);
        c4.setCellValueFactory(new PropertyValueFactory<>("album"));

        TableColumn c5 = new TableColumn("大小");
        c5.setPrefWidth(100);
        c5.setCellValueFactory(new PropertyValueFactory<>("length"));

        TableColumn c6 = new TableColumn("时长");
        c6.setPrefWidth(50);
        c6.setCellValueFactory(new PropertyValueFactory<>("time"));

        TableColumn c7 = new TableColumn("类型");
        c7.setPrefWidth(50);
        c7.setCellValueFactory(new PropertyValueFactory<>("soundType"));


        TableColumn c8 = new TableColumn("操作");
        c8.setPrefWidth(50);
        c8.setMaxWidth(50);
        c8.setCellValueFactory(new PropertyValueFactory<>("labDelete"));


        tableView.getColumns().addAll(c1,c2,c3,c4,c5,c6,c7,c8);

        //添加行双击事件
        tableView.setRowFactory(tv ->{
            TableRow<PlayBean> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if(event.getClickCount() == 2 && !row.isEmpty()) {
                    // 获取选中行索引
                    this.currentIndex = row.getIndex();
                    // 将前一秒设置为0
                    this.preSecond = 0;
                    //判断当前是否在播放 如果是则停止
                    if (this.currentPlayBean != null) {
                        this.currentPlayBean.getMediaPlayer().stop();
                    }
                    //获取当前播放信息
                    this.currentPlayBean = row.getItem();
                    // 播放
                    play();
                }
            });
            return row;
        });

        BorderPane borderPane = new BorderPane();
        borderPane.setTop(scrollPane);
        borderPane.setCenter(tableView);
//        最后一列绑定宽度
        c8.prefWidthProperty().bind(borderPane.widthProperty());

        return borderPane;
    }

    private void play() {

        // 设置总时间 进度条两边的label
        this.labelTotalTime.setText(this.currentPlayBean.getTime());
        // 设置滚动条
        this.sliderSong.setMax(this.currentPlayBean.getTotalSeconds());
        this.sliderSong.setMajorTickUnit(1);//每次动一格
        //设置初始值
        this.sliderSong.setValue(0);
        preSecond = 0;

        //设置初始音量
        this.currentPlayBean.getMediaPlayer().setVolume(this.volumeProgress.getProgress());

//         开始播放
        new Thread(){
            @Override
            public void run(){
                currentPlayBean.getMediaPlayer().play();
            }
        }.start();
        //设置碟片
            if(this.currentPlayBean.getImage() != null){
                this.panImageview.setImage(this.currentPlayBean.getImage());
            }else {
                this.panImageview.setImage(new Image("image/pan.png"));
            }

            this.timeline.stop();
            this.timeline.play();
            // 设置背景
            WritableImage wImage = this.currentPlayBean.getImage();
            if(wImage != null){
                WritableImage newWritableImage = new WritableImage(
                        (int)wImage.getWidth(),
                        (int) wImage.getHeight()
                );
                PixelReader pr = wImage.getPixelReader();
                PixelWriter pw = newWritableImage.getPixelWriter();
                for (int i = 0; i < wImage.getHeight(); i++) {
                    for (int j = 0; j < wImage.getWidth(); j++) {
                        Color color = pr.getColor(i,j);
                        for (int k = 0; k < 4; k++) {
                            color= color.darker();
                        }
                        pw.setColor(i,j,color);
                    }

                }
                this.backImageView.setImage(newWritableImage);
            }else {
//                Image image = new Image("image/Logo.png");
//                WritableImage writableImage = new WritableImage(
//                        (int)image.getWidth(),
//                        (int) image.getHeight()
//                );
//                PixelReader pr = image.getPixelReader();
//                PixelWriter pw = writableImage.getPixelWriter();
//                for (int i = 0; i < image.getHeight(); i++) {
//                    for (int j = 0; j < image.getWidth(); j++) {
//                        Color color = pr.getColor((int)i, (int)j);
//                        for (int k = 0; k < 4; k++) {
//                            color= color.darker();
//                        }
//                        pw.setColor(i,j,color);
//                    }
//
//                }
                this.backImageView.setImage(null);
            }
            //设置播放按钮变成暂停
        this.buttonPlayImage.setImage(new Image("image/stop.png"));
        this.labelPlay.setOnMouseEntered(event -> {buttonPlayImage.setImage(new Image("image/start.png"));});
        this.labelPlay.setOnMouseExited(event -> {buttonPlayImage.setImage(new Image("image/stop.png"));});

    }

    // 窗体的上框框
    private BorderPane getTopPane(){
        ImageView imageView = new ImageView("image/Logo.png");
        imageView.setFitWidth(40);// 设置图片的高度
        imageView.setPreserveRatio(true);//保持比例


//        设置一个跳转按钮
        Label information_label = new Label("文案");
        information_label.setPrefHeight(30);
        information_label.setPrefWidth(50);
        information_label.setMinWidth(50);
        information_label.setMinHeight(30);
        information_label.setStyle("" +
                "-fx-background-color: white;" + "-fx-background-radius: 25px;"
        );
        information_label.setAlignment(Pos.CENTER);

        information_label.setOnMouseClicked(event -> {
            MainText.main_stage.show();
        });

        information_label.setOnMouseEntered(event -> {
            information_label.setStyle("-fx-background-color: #CC6600;" + "-fx-text-fill: white;" + "-fx-background-radius: 25px;");

        });

        information_label.setOnMouseExited(event -> {
            information_label.setStyle("-fx-background-color: white;" + "-fx-text-fill: black;" + "-fx-background-radius: 25px;");
        });


        HBox hBox = new HBox(20);
        hBox.setAlignment(Pos.CENTER_LEFT);// 设置向左对其
        hBox.setPrefHeight(500);
        hBox.setPrefWidth(500);
        hBox.setMaxWidth(50);
        hBox.setMaxHeight(50);
        hBox.setPadding(new Insets(10,0,10,30)); //设置这个box和外界的间隔
        hBox.getChildren().addAll(imageView, information_label);




//      搜索栏
        TextField search = new  TextField();
        search.setPromptText("anything");
        search.setPrefWidth(200);
        search.setPrefHeight(15);
        search.setMaxHeight(15);
        search.setMaxWidth(200);
//        放大镜图标
        ImageView big_mirror = new ImageView("image/max_mirror.png");
        big_mirror.setFitHeight(30);
        big_mirror.setFitHeight(30);
        Label label_bigger = new Label("",big_mirror);
        label_bigger.setMinWidth(0);
        label_bigger.setMinHeight(0);
        label_bigger.setPrefHeight(30);
        label_bigger.setPrefWidth(30);
        label_bigger.setOnMouseClicked(event -> {
            System.out.println(search.getText());
            readLimitSound(search.getText());
        });

        HBox hBox_center = new HBox(10);
        hBox_center.setPadding(new Insets(10,30,10,0));
        hBox_center.setAlignment(Pos.CENTER);
        hBox_center.setPrefWidth(250);
        hBox_center.setPrefHeight(30);
        hBox_center.getChildren().addAll(label_bigger,search);


        // 设置右侧的那几个按钮
        // 最大化按钮
        ImageView max = new ImageView("image/minimal.png");
        max.setFitWidth(30);
        max.setFitHeight(30);

        Label label = new Label("",max);
        label.setMinWidth(0);
        label.setMinHeight(0);
        label.setPrefHeight(30);
        label.setPrefWidth(30);

        label.setOnMouseEntered(event -> max.setImage(new Image("image/Maximal.png")));
        label.setOnMouseExited(event -> max.setImage(new Image("image/minimal.png")));
        // 最大化 需要判定窗体的状态
        label.setOnMouseClicked(event -> {
            if(!staticScreen.isMaximized()){
//                记录信息
                reSet_X = staticScreen.getX();
                reSet_Y = staticScreen.getY();
                reSet_H = staticScreen.getHeight();
                reSet_W = staticScreen.getWidth();
                staticScreen.setMaximized(true);
            }else {
                staticScreen.setMaximized(false);
                staticScreen.setX(reSet_X);
                staticScreen.setY(reSet_Y);
                staticScreen.setHeight(reSet_H);
                staticScreen.setWidth(reSet_W);

            }
        });

//        最小化按钮
        ImageView min = new ImageView("image/while__.png");
        min.setFitWidth(30);
        min.setFitHeight(30);

        Label label1 = new Label("",min);
        label1.setMinWidth(0);
        label1.setMinHeight(0);
        label1.setPrefHeight(30);
        label1.setPrefWidth(30);

        label1.setOnMouseEntered(event -> min.setImage(new Image("image/black__.png")));
        label1.setOnMouseExited(event -> min.setImage(new Image("image/while__.png")));
        // 鼠标点击
        label1.setOnMouseClicked(event -> staticScreen.setIconified(true));

//        关闭按钮
        ImageView close = new ImageView("image/black_X.png");
        close.setFitWidth(30);
        close.setFitHeight(30);

        Label label2 = new Label("",close);
        label2.setMinWidth(0);
        label2.setMinHeight(0);
        label2.setPrefHeight(30);
        label2.setPrefWidth(30);

        label2.setOnMouseEntered(event -> close.setImage(new Image("image/red_X.png")));
        label2.setOnMouseExited(event -> close.setImage(new Image("image/black_X.png")));
        label2.setOnMouseClicked(event -> {
            // 后期在这里有一个记录播放歌曲的东西
            System.exit(0);
        });

        HBox hBox1 = new HBox(20); //内部元素之间的间距为10
        hBox1.setPadding(new Insets(10,30,10,0));
        hBox1.setAlignment(Pos.CENTER_LEFT);
        hBox1.setPrefWidth(150);
        hBox1.setPrefHeight(50);
        hBox1.getChildren().addAll(label1,label,label2);

        // 设置一个装饰用的紫线
        Rectangle rect = new Rectangle();
        rect.setX(0);
        rect.setY(0);
        rect.setWidth(100);
        rect.setHeight(10);
        // 设置背景色 渐变 stop 表示梯度
        Stop[] stops =new Stop[]{
                new Stop(0,Color.rgb(205, 149, 12)),
                new Stop(0.5,Color.rgb(238, 173, 14)),
                new Stop(1,Color.rgb(255, 185, 15))
        }; // 一个渐变的操作
        rect.setFill(new LinearGradient(0,0,1,1,true, CycleMethod.NO_CYCLE,stops));

        BorderPane topPane = new BorderPane();
        topPane.setBottom(rect); // 设置到底部了
        topPane.setLeft(hBox);
        topPane.setRight(hBox1);
        topPane.setCenter(hBox_center);
        topPane.setStyle("-fx-background-color: rgb(255, 193, 37);");

        //将红线的宽度和屏幕保持一致
        rect.widthProperty().bind(staticScreen.widthProperty());


        // 设置 拖拽功能
        topPane.setOnMousePressed(event -> { // 鼠标点击
            // 记录鼠标相对于窗口的坐标x，y
            mouse_X = event.getSceneX();
            mouse_Y = event.getSceneY();

        });
        topPane.setOnMouseDragged(event -> {
            staticScreen.setX(event.getScreenX()-mouse_X);
            staticScreen.setY(event.getScreenY()-mouse_Y);
        });


        return topPane;
    }

    // 窗体的左侧面板
    private BorderPane getLeftPane(){

        ImageView image_1 = new ImageView("image/Logo.png");
        image_1.setFitWidth(260);
        image_1.setPreserveRatio(true); // 设置等比例

        // 作者名字
        Label labelAuthor = new Label("潮乐数据盒");
        labelAuthor.setPrefWidth(260);
        labelAuthor.setTextFill(Color.rgb(139, 105, 20));        // 设置颜色和字体
        labelAuthor.setFont(new Font("宋体",20));
        labelAuthor.setAlignment(Pos.CENTER);

        Label label_version = new Label("version:0.0.1");
        label_version.setPrefWidth(260);
        label_version.setFont(new Font("宋体",20));
        label_version.setAlignment(Pos.CENTER);
        label_version.setTextFill(Color.rgb(139, 105, 20));

        // 设置歌单列表
        Label music_table = new Label("已创建歌单");
        music_table.setPrefWidth(240);
        music_table.setPrefHeight(30);
        music_table.setTextFill(Color.rgb(139, 105, 20));

        // 创造歌单左边的符号
        ImageView add_1 = new ImageView("image/add_while.png");
        add_1.setFitWidth(20);
        add_1.setPreserveRatio(true);

        Label label_1 = new Label("",add_1);
        label_1.setPrefWidth(20);
        label_1.setPrefHeight(20);
        label_1.setOnMouseEntered(event -> {add_1.setImage(new Image("image/add_black.png"));});
        label_1.setOnMouseExited(event -> {add_1.setImage(new Image("image/add_while.png"));});
        label_1.setOnMouseClicked(event -> {
//            new  add_screen(staticScreen, vBox1,this);
            Label label = new Label("新建歌单");
            label.setTextFill(Color.ORANGE);
            label.setPrefHeight(150);
            label.setPrefWidth(50);
            label.setLayoutX(10);
            label.setLayoutY(-10);

//            // 关闭按钮
//            ImageView close = new ImageView("image/black_X.png");
//            close.setFitWidth(20);
//            close.setFitHeight(20);

//            Label label1 = new Label("",close);
//            label1.setMinWidth(20);
//            label1.setMinHeight(20);
//            label1.setPrefHeight(20);
//            label1.setPrefWidth(20);
//            label1.setLayoutX(270);
//            label1.setLayoutY(0);
//            label1.setOnMouseEntered(event1 -> close.setImage(new Image("image/red_X.png")));
//            label1.setOnMouseExited(event1 -> close.setImage(new Image("image/black_X.png")));
//            label1.setOnMouseClicked(event1 -> stage.hide());

            //文本框
            TextField text_group_name = new TextField();
            text_group_name.setPromptText("请输入歌单名称");
            text_group_name.setPrefWidth(220);
            text_group_name.setPrefHeight(15);
            text_group_name.setLayoutX(20);
            text_group_name.setLayoutY(10);

            // 列表存在的提示框
            Label label2 = new Label();
            label2.setPrefWidth(200);
            label2.setLayoutX(20);
            label2.setLayoutY(30);
            label2.setTextFill(Color.RED);

//        确定按钮
            Button button_ok = new Button("确定");
            button_ok.setPrefWidth(80);
            button_ok.setPrefHeight(30);
            button_ok.setLayoutX(50);
            button_ok.setLayoutY(100);
            button_ok.setBackground(new Background(new BackgroundFill(Color.rgb(255, 185, 15),null,null)));
            button_ok.setOnMouseClicked(event1 -> {
                // 获取文本框数据
                String txt = text_group_name.getText().trim();
                if (txt.length() == 0){
                    label2.setText("请输入歌单名称");
                } else {
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
                        Connection con = DriverManager.getConnection(URL, USER, PASS);
                        String sql_1 = "SELECT table_name FROM information_schema.TABLES WHERE table_name ='" + txt + "';";
                        PreparedStatement doing = con.prepareStatement(sql_1);
                        ResultSet result = doing.executeQuery();
                        if(!result.next()){
                            String sql_2 = "CREATE TABLE "+txt+" (" +
                                    "id SMALLINT AUTO_INCREMENT NOT NULL PRIMARY KEY," +
                                    "music_name VARCHAR(50), music_content LONGBLOB, music_type varchar(30),artist varchar(30),album varchar(30)) ;";
                            Statement statement = con.createStatement();
                            statement.executeUpdate(sql_2);
                            // 创造hbox
                            // 心形图标
                            ImageView love_image = new ImageView("image/vacant_love.png");
                            love_image.setFitWidth(20);
                            love_image.setPreserveRatio(true);
                            Label label_love = new Label("",love_image);
                            label_love.setMinHeight(0);
                            label_love.setMinWidth(0);
                            label_love.setPrefWidth(20);
                            label_love.setPrefHeight(20);
                            label_love.setOnMouseEntered(event_2 -> love_image.setImage(new Image("image/red_love.png")));
                            label_love.setOnMouseExited(event_2 -> love_image.setImage(new Image("image/vacant_love.png")));

                            // 歌单名称
                            Label song_table_name = new Label(txt);
                            song_table_name.setMinHeight(0);
                            song_table_name.setPrefHeight(20);
                            song_table_name.setPrefWidth(160);
                            song_table_name.setTextFill(Color.rgb(139, 69, 19));
                            //这里有一个移入高亮
                            song_table_name.setOnMouseEntered(event_2 -> song_table_name.setTextFill(Color.rgb(255, 127, 0)));
                            song_table_name.setOnMouseExited(event_2 -> song_table_name.setTextFill(Color.rgb(139, 69, 19)));

                            // 播放按钮
                            ImageView iv2 = new ImageView("image/play_while.png");
                            iv2.setFitWidth(20);
                            iv2.setPreserveRatio(true);
                            Label label_play = new Label("",iv2);
                            label_play.setMinHeight(0);
                            label_play.setMinWidth(0);
                            label_play.setPrefWidth(20);
                            label_play.setPrefHeight(20);
                            label_play.setOnMouseEntered(event_2 -> iv2.setImage(new Image("image/play_green.png")));
                            label_play.setOnMouseExited(event_2 -> iv2.setImage(new Image("image/play_while.png")));
                            label_play.setOnMouseClicked(event_2 -> {
                                this.labelGroupName.setText(song_table_name.getText());
                                //读取歌单下所有的歌曲
                                readAllSoundByGroup();
//                    for (show_song_from_table i: list){
//                        System.out.println(i.getFilepath());
//                    }
                            });

                            // 添加
                            ImageView imageView = new ImageView("image/small_add.png");
                            imageView.setFitWidth(20);
                            imageView.setPreserveRatio(true);
                            Label label3 = new Label("",imageView);
                            label3.setMinHeight(0);
                            label3.setMinWidth(0);
                            label3.setPrefWidth(20);
                            label3.setPrefHeight(20);
                            label3.setOnMouseEntered(event_2 -> {imageView.setImage(new Image("image/blue_add.png"));});
                            label3.setOnMouseExited(event_2 -> {imageView.setImage(new Image("image/small_add.png"));});
                            label3.setOnMouseClicked(event_2 -> {
                                FileChooser fileChooser = new FileChooser();
                                fileChooser.setTitle("请选择音乐");
                                // 过滤文件
                                fileChooser.getExtensionFilters().addAll(
                                        new FileChooser.ExtensionFilter("Mp3","*.mp3"),
                                        new FileChooser.ExtensionFilter("flac","*.flac"),
                                        new FileChooser.ExtensionFilter("所有文件","*.*"));
                                File files = fileChooser.showOpenDialog(staticScreen);
                                if(files != null){
                                    // 写入文件
                                    String text = song_table_name.getText();
                                    System.out.println(text);
                                    System.out.println(files);
                                    if(upload_music.upload(files,text)){
                                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                                        alert.setTitle("成功！");
                                        alert.setHeaderText("音乐添加成功");
                                        alert.showAndWait();
                                        this.labelGroupName.setText(song_table_name.getText());
                                        readAllSoundByGroup();
                                    }else {
                                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                                        alert.setTitle("失败！");
                                        alert.setHeaderText("音乐已在歌单中");
                                        alert.showAndWait();
                                    }
                                }
                            });


                            // 垃圾桶;
                            ImageView iv3 = new ImageView("image/ash-bin_dark.png");
                            iv3.setFitWidth(20);
                            iv3.setPreserveRatio(true);
                            Label label_delete = new Label("",iv3);
                            label_delete.setMinHeight(0);
                            label_delete.setMinWidth(0);
                            label_delete.setPrefWidth(20);
                            label_delete.setPrefHeight(20);
                            label_delete.setOnMouseEntered(event_2 -> iv3.setImage(new Image("image/ash-bin_colorful.png")));
                            label_delete.setOnMouseExited(event_2 -> iv3.setImage(new Image("image/ash-bin_dark.png")));

                            HBox hBox1 = new HBox(10);//间距10
                            hBox1.getChildren().addAll(label_love,song_table_name,label_play,label3,label_delete);
                            hBox1.setPadding(new Insets(5,5,5,10));

                            hBoxList.add(hBox1); // 将每个hbox添加到列表

                            label_delete.setOnMouseClicked(event_2 -> {
                                // 弹出提示
                                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                                alert.setTitle("确认删除");
                                alert.setHeaderText("你确认要删除歌单【"+song_table_name.getText()+"】");
                                Optional<ButtonType> buttonType = alert.showAndWait();
                                if (buttonType.get() == ButtonType.OK){
                                    delete_table.delete_music_table(song_table_name.getText());
                                    this.vBox1.getChildren().remove(hBox1);
                                    labelGroupName.setText(" ");
                                }
                            });
                            // 更新列表
                            this.vBox1.getChildren().add(hBox1);
                            label_delete.setText("创造成功");
                            this.stage.hide();
                        }else {
                            label2.setText("歌单已经存在");
                        }
                    }catch (ClassNotFoundException | SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            });


            // 取消
            Button button_cancel = new Button("取消");
            button_cancel.setPrefWidth(80);
            button_cancel.setPrefHeight(30);
            button_cancel.setLayoutX(150);
            button_cancel.setLayoutY(100);  //这地方可以修改
            button_cancel.setBackground(new Background(new BackgroundFill(Color.rgb(255, 255, 224),null,null)));
            button_cancel.setOnMouseClicked(event1 -> stage.hide());

            // 创造一个舞台对象 就是大概底板 或者地基
            stage = new Stage();
            stage.initStyle(StageStyle.UTILITY );
            // 创造一个场景
            Group group = new Group();
            group.getChildren().addAll(label,text_group_name,label2,button_ok,button_cancel);
            Scene scene = new Scene(group,300,150);
            scene.setOnMousePressed(event1 -> {
                mouse_X = event1.getSceneX();
                mouse_Y = event1.getSceneY();
            }); // 场景的拖拽
            scene.setOnMouseDragged(event1 -> {
                stage.setX(event1.getScreenX()-mouse_X);
                stage.setY(event1.getScreenY()-mouse_Y);
            });

            // 设置场景
            stage.setScene(scene);
            stage.show();

        });


//        封装歌单标题和按钮的hbox
        HBox hBox = new HBox(5);//元素之间的间距
        hBox.getChildren().addAll(music_table,label_1);

        // 将目前为止的元素存到 一个vbox里
        VBox groupVBox = new VBox(15);//间距 应该是竖着的
        groupVBox.setPrefWidth(260);
        groupVBox.setPrefHeight(400);
        groupVBox.setPadding(new Insets(5,5,5,10)); // 元素和vbox的内间距
        groupVBox.getChildren().addAll(image_1,labelAuthor,label_version,hBox);



        // 读取歌单
        List<String> groupList = search_table.readAllGroup();
        hBoxList = new ArrayList<>();
        // 将每个歌单名字分装成hbox
        for (String group_name:groupList){
//            心形图标
             ImageView love_image = new ImageView("image/vacant_love.png");
             love_image.setFitWidth(20);
             love_image.setPreserveRatio(true);
             Label label = new Label("",love_image);
             label.setMinHeight(0);
             label.setMinWidth(0);
             label.setPrefWidth(20);
             label.setPrefHeight(20);
             label.setOnMouseEntered(event -> love_image.setImage(new Image("image/red_love.png")));
             label.setOnMouseExited(event -> love_image.setImage(new Image("image/vacant_love.png")));

             // 歌单名称
             Label song_table_name = new Label(group_name);
             song_table_name.setMinHeight(0);
             song_table_name.setPrefHeight(20);
             song_table_name.setPrefWidth(160);
             song_table_name.setTextFill(Color.rgb(139, 69, 19));
             //这里有一个移入高亮
             song_table_name.setOnMouseEntered(event -> song_table_name.setTextFill(Color.rgb(255, 127, 0)));
             song_table_name.setOnMouseExited(event -> song_table_name.setTextFill(Color.rgb(139, 69, 19)));

             // 播放按钮
             ImageView iv2 = new ImageView("image/play_while.png");
             iv2.setFitWidth(20);
             iv2.setPreserveRatio(true);
             Label label1 = new Label("",iv2);
             label1.setMinHeight(0);
             label1.setMinWidth(0);
             label1.setPrefWidth(20);
             label1.setPrefHeight(20);
             label1.setOnMouseEntered(event -> iv2.setImage(new Image("image/play_green.png")));
             label1.setOnMouseExited(event -> iv2.setImage(new Image("image/play_while.png")));
             label1.setOnMouseClicked(event -> {
                this.labelGroupName.setText(song_table_name.getText());
                //读取歌单下所有的歌曲
                 readAllSoundByGroup();
//                    for (show_song_from_table i: list){
//                        System.out.println(i.getFilepath());
//                    }
             });

             // 添加
             ImageView imageView = new ImageView("image/small_add.png");
             imageView.setFitWidth(20);
             imageView.setPreserveRatio(true);
             Label label3 = new Label("",imageView);
             label3.setMinHeight(0);
             label3.setMinWidth(0);
             label3.setPrefWidth(20);
             label3.setPrefHeight(20);
             label3.setOnMouseEntered(event -> {imageView.setImage(new Image("image/blue_add.png"));});
             label3.setOnMouseExited(event -> {imageView.setImage(new Image("image/small_add.png"));});
             label3.setOnMouseClicked(event -> {
                 FileChooser fileChooser = new FileChooser();
                 fileChooser.setTitle("请选择音乐");
                 // 过滤文件
                 fileChooser.getExtensionFilters().addAll(
                         new FileChooser.ExtensionFilter("Mp3","*.mp3"),
                         new FileChooser.ExtensionFilter("flac","*.flac"),
                         new FileChooser.ExtensionFilter("所有文件","*.*"));
                 File files = fileChooser.showOpenDialog(staticScreen);
                 if(files != null){
                     // 写入文件
                     String txt = song_table_name.getText();
                     System.out.println(txt);
                     System.out.println(files);
                     if(upload_music.upload(files,txt)){
                         Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                         alert.setTitle("成功！");
                         alert.setHeaderText("音乐添加成功");
                         alert.showAndWait();
                         readAllSoundByGroup();
                     }else {
                         Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                         alert.setTitle("失败！");
                         alert.setHeaderText("音乐已在歌单中");
                         alert.showAndWait();
                     }
                 }
             });


             // 垃圾桶;
             ImageView iv3 = new ImageView("image/ash-bin_dark.png");
             iv3.setFitWidth(20);
             iv3.setPreserveRatio(true);
             Label label2 = new Label("",iv3);
             label2.setMinHeight(0);
             label2.setMinWidth(0);
             label2.setPrefWidth(20);
             label2.setPrefHeight(20);
             label2.setOnMouseEntered(event -> iv3.setImage(new Image("image/ash-bin_colorful.png")));
             label2.setOnMouseExited(event -> iv3.setImage(new Image("image/ash-bin_dark.png")));

             HBox hBox1 = new HBox(10);//间距10
             hBox1.getChildren().addAll(label,song_table_name,label1,label3,label2);
             hBox1.setPadding(new Insets(5,5,5,10));

             hBoxList.add(hBox1); // 将每个hbox添加到列表

            label2.setOnMouseClicked(event -> {
                // 弹出提示
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("确认删除");
                alert.setHeaderText("你确认要删除歌单【"+song_table_name.getText()+"】");
                Optional<ButtonType> buttonType = alert.showAndWait();
                if (buttonType.get() == ButtonType.OK){
                    delete_table.delete_music_table(song_table_name.getText());
                    this.vBox1.getChildren().remove(hBox1);
                    labelGroupName.setText(" ");
                }
            });
            }



//        把各个hbox合起来
        vBox1 = new VBox(10);
        vBox1.setPrefWidth(260);
        vBox1.setPadding(new Insets(10,0,0,15));
        for (HBox hb:hBoxList){
            vBox1.getChildren().addAll(hb);
        }

        BorderPane LeftPane = new BorderPane();
        LeftPane.setCenter(vBox1);
        LeftPane.setTop(groupVBox);
        return LeftPane;

 
    }

    // 下侧框框
    private BorderPane getBottomPane() {
        // 左侧的三个按钮
        // 上一首
        ImageView imageView1 = new ImageView("image/last.png");
        imageView1.setFitHeight(50);
        imageView1.setFitWidth(50);
        Label label1 = new Label("",imageView1);
        label1.setOnMouseEntered(event -> imageView1.setImage(new Image("image/smile_left.png")));
        label1.setOnMouseExited(event -> imageView1.setImage(new Image("image/last.png")));
        label1.setOnMouseClicked(event -> {
            if(this.currentPlayBean != null){
                this.currentPlayBean.getMediaPlayer().stop();
            }
            this.timeline.stop();
            this.currentIndex--;
            if (currentIndex<0){
                if (this.PlayMode ==1){
                    this.currentIndex = this.tableView.getItems().size()-1;//定位到最后一首歌
                }else {
                    this.currentIndex = 0;
                }
            } // 设置table选中
            this.tableView.getSelectionModel().select(currentIndex);
            // 设置播放对象
            this.currentPlayBean = this.tableView.getItems().get(currentIndex);
            play();
        });
        // 播放
        buttonPlayImage = new ImageView("image/start.png");
        buttonPlayImage.setFitHeight(60);
        buttonPlayImage.setFitWidth(60);
        labelPlay = new Label("",buttonPlayImage);
        labelPlay.setOnMouseEntered(event -> buttonPlayImage.setImage(new Image("image/start_highlight.png")));
        labelPlay.setOnMouseExited(event -> buttonPlayImage.setImage(new Image("image/start.png")));
        labelPlay.setOnMouseClicked(event -> {
            //如果正在播放 暂停
            if (this.currentPlayBean.getMediaPlayer().getStatus() == MediaPlayer.Status.PLAYING){
                this.currentPlayBean.getMediaPlayer().pause();
                // 设置播放按钮图标为播放
                buttonPlayImage.setImage(new Image("image/stop.png"));
                labelPlay.setOnMouseEntered(event_0 -> buttonPlayImage.setImage(new Image("image/start_highlight.png")));
                labelPlay.setOnMouseExited(event_0 -> buttonPlayImage.setImage(new Image("image/start.png")));
                // 暂停旋转的盘子
                this.timeline.pause();
            }else if (this.currentPlayBean.getMediaPlayer().getStatus() == MediaPlayer.Status.PAUSED){
                this.currentPlayBean.getMediaPlayer().play();
                this.timeline.play();
                buttonPlayImage.setImage(new Image("image/start_highlight.png"));
                labelPlay.setOnMouseEntered(event_0 -> buttonPlayImage.setImage(new Image("image/stop_highlight.png")));
                labelPlay.setOnMouseExited(event_0 -> buttonPlayImage.setImage(new Image("image/stop.png")));

            }
        });

        // 下一首
        ImageView imageView3 = new ImageView("image/next.png");
        imageView3.setFitHeight(50);
        imageView3.setFitWidth(50);
        Label label3 = new Label("",imageView3);
        label3.setOnMouseEntered(event -> imageView3.setImage(new Image("image/smile_right.png")));
        label3.setOnMouseExited(event -> imageView3.setImage(new Image("image/next.png")));
        label3.setOnMouseClicked(event -> {
            if(this.currentPlayBean != null){
                this.currentPlayBean.getMediaPlayer().stop();
            }
            this.timeline.stop();
            // 停止播放器
            // 根据当前播放模式选择下一首
            switch (this.PlayMode){
                case 1: // 列表乱循序播放
                    Random random = new Random();
                    int number = random.nextInt(tableView.getItems().size());
                    this.currentIndex += number;
                    if (this.currentIndex >= this.tableView.getItems().size()){
                        currentIndex %= number;
                    }
                    this.currentPlayBean = tableView.getItems().get(this.currentIndex);
                    break;
                case 2: // 循环播放
                    this.currentIndex++;
                    if (this.currentIndex >= this.tableView.getItems().size()){
                        this.currentIndex = 0;
                    }
                    this.currentPlayBean = tableView.getItems().get(this.currentIndex);
                    break;
                case 3: // 单曲循环
                    this.currentPlayBean.getMediaPlayer().seek(new Duration(0));
                    break;
            }
            this.tableView.getSelectionModel().select(currentIndex);
            play();

//            this.currentIndex++; // 索引加一
//            if (currentIndex>= this.tableView.getItems().size()){
//                if (this.PlayMode ==1){
//                    this.currentIndex = 0;
//                }else {
//                    this.currentIndex = this.tableView.getItems().size()-1;//定位到最后一首歌
//                }
//            } // 设置table选中
//            this.tableView.getSelectionModel().select(currentIndex);
//            // 设置播放对象
//            this.currentPlayBean = this.tableView.getItems().get(currentIndex);
//            play();
        });

        HBox hBox1 = new HBox(30);
        hBox1.setPrefWidth(260);
        hBox1.setPadding(new Insets(10,10,10,20));
        hBox1.getChildren().addAll(label1,labelPlay,label3);
        //**************************中间滚动条*********************************


        // 已经播放的标签
        labelPlayTime = new Label("00:00");
        labelPlayTime.setPrefHeight(40);
        labelPlayTime.setPrefHeight(50);
        labelPlayTime.setTextFill(Color.rgb(139, 117, 0));


        // 滚动条
        sliderSong = new Slider();
        sliderSong.setMinWidth(0);
        sliderSong.setMinHeight(0);
        sliderSong.setPrefHeight(12);
        sliderSong.setPrefWidth(500);
        sliderSong.getStylesheets().add("css/music_slide.css");


        // 进度条
        ProgressBar progressBar = new ProgressBar();
        progressBar.setProgress(0);
        progressBar.setMinWidth(0);
        progressBar.setMinHeight(0);

        progressBar.setMaxWidth(5000);
        progressBar.setPrefWidth(300);
        progressBar.getStylesheets().add("css/music_slide.css");
// 使用栈的模板来存储两个滚动条
        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(progressBar,sliderSong);

        // 当滚动条值发生变化时
        sliderSong.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                if (currentPlayBean!= null){
                    progressBar.setProgress((newValue.doubleValue()+1)/currentPlayBean.getTotalSeconds());
                }
            }
        });




        //Slider 的鼠标抬起事件
        sliderSong.setOnMouseReleased(event -> {
            if (currentPlayBean != null){
                Duration duration = new Duration(sliderSong.getValue()*1000);
                currentPlayBean.getMediaPlayer().seek(duration);

                // 同时设计label
                Date data = new Date();
                data.setTime((long) currentPlayBean.getMediaPlayer().getCurrentTime().toMillis());
                labelPlayTime.setText(new SimpleDateFormat("mm:ss").format(data));
                preSecond = (int)duration.toSeconds()-1;
            }
        });

//        总时间标签
        labelTotalTime = new Label("00:00");
        labelTotalTime.setPrefHeight(40);
        labelTotalTime.setPrefWidth(50);
        labelTotalTime.setTextFill(Color.rgb(139, 117, 0));
        labelTotalTime.setAlignment(Pos.CENTER_RIGHT);
        BorderPane borderPane = new BorderPane();
        borderPane.setLeft(labelPlayTime);
        borderPane.setCenter(stackPane);
        borderPane.setRight(labelTotalTime);
        BorderPane bottomPane = new BorderPane();
        // 音量
        ImageView imageView4 = new ImageView("image/sound.png");
        imageView4.setFitWidth(17);
        imageView4.setFitHeight(17);
        Label label5 = new Label("",imageView4);
        label5.setOnMouseEntered(event -> imageView4.setImage(new Image("image/sound_highlight.png")));
        label5.setOnMouseExited(event -> imageView4.setImage(new Image("image/sound.png")));
        label5.setOnMouseClicked(event -> {
            if(this.currentPlayBean != null){
                // 判断当前音量
                if (this.currentPlayBean.getMediaPlayer().getVolume() != 0){
                    // 存储当前音量
                    this.prevVolume = this.currentPlayBean.getMediaPlayer().getVolume();
                    this.currentPlayBean.getMediaPlayer().setVolume(0); // 不是静音设静音
                    imageView4.setImage(new Image("image/not_sound.png"));
                    label5.setOnMouseEntered(event1 -> imageView4.setImage(new Image("image/not_sound_highlight.png")));
                    label5.setOnMouseExited(event1 -> imageView4.setImage(new Image("image/not_sound.png")));

                    // 设置音量滚动条
                    this.sliderVolume.setValue(0);
                }else {
                    //恢复原来的音量
                    this.currentPlayBean.getMediaPlayer().setVolume(this.prevVolume);
                    imageView4.setImage(new Image("image/sound.png"));
                    label5.setOnMouseEntered(event1 -> imageView4.setImage(new Image("image/sound_highlight.png")));
                    label5.setOnMouseExited(event1 -> imageView4.setImage(new Image("image/sound.png")));

                    // 恢复音量滚动条
                    this.sliderVolume.setValue(this.prevVolume*100);
                }
            }
        });
        //音量滚动条
        sliderVolume = new Slider();
        sliderVolume.setMax(100); // 最大音量
        sliderVolume.setValue(50); // 默认50
        sliderVolume.setMajorTickUnit(1); // 每次变动1
        sliderVolume.setMinHeight(0);
        sliderVolume.setPrefHeight(10);
        sliderVolume.setPrefWidth(100);
        sliderVolume.getStylesheets().add("css/music_slide.css");
        // 进度条
        this.volumeProgress = new ProgressBar();
        this.volumeProgress.setMinHeight(0);
        this.volumeProgress.setProgress(0.5); // 初始在中间
        this.volumeProgress.setPrefWidth(100);
        this.volumeProgress.setPrefHeight(10);
        this.volumeProgress.prefWidthProperty().bind(sliderVolume.prefWidthProperty()); // 确保宽度一致
        this.volumeProgress.getStylesheets().add("css/music_slide.css");
        //监听音量进度条的鼠标抬起事件

        //进度条的值发生变化时
        sliderVolume.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                volumeProgress.setProgress(sliderVolume.getValue()/100);
                if (currentPlayBean != null) {
                    currentPlayBean.getMediaPlayer().setVolume(volumeProgress.getProgress());
                }
            }
        });


        StackPane stackPane1 = new StackPane();
        stackPane1.getChildren().addAll(this.volumeProgress,sliderVolume);

        //播放模式图片
        ImageView imageView5 = new ImageView("image/随机播放.png");
        imageView5.setFitWidth(25);
        imageView5.setFitHeight(25);
        Label label6 = new Label("",imageView5);
        label6.setOnMouseEntered(event -> label6.setCursor(Cursor.HAND));
        label6.setOnMouseExited(event -> label6.setCursor(Cursor.DEFAULT));
        label6.setOnMouseClicked(event -> {
            // 这里只有标记
            this.PlayMode++;
            if (this.PlayMode>3){
                this.PlayMode = 1;
            }
            switch (this.PlayMode){
                case 1:
                    imageView5.setImage(new Image("image/随机播放.png"));
                    break;
                case 2:
                    imageView5.setImage(new Image("image/循环播放.png"));
                    break;
                case 3:
                    imageView5.setImage(new Image("image/单曲循环.png"));
                    break;
            }
                });

        // 歌词图片
        ImageView imageView6 = new ImageView("image/歌词.png");
        imageView6.setFitWidth(25);
        imageView6.setFitHeight(25);
        Label label7 = new Label("",imageView6);
        // 拖拽
//        ImageView imageView7 = new ImageView("image/拖拽.png");
//        imageView7.setFitWidth(30);
//        imageView7.setFitHeight(50);
//        Label label8 = new Label("",imageView7);
//        label8.setOnMousePressed(event -> {
//            xOffset = event.getSceneX();
//            yOffset = event.getSceneY();
//        });
//        label8.setOnMouseMoved(event -> {
//            if (event.getY()>34 && event.getY()<50 &&
//            event.getX()>0&& event.getX()<30){
////                改变鼠标形状
//            label8.setCursor(Cursor.NW_RESIZE);
//            }
//        });
//        label8.setOnMouseDragged(event -> {
//            if(staticScreen.getWidth()+(event.getScreenX()-xOffset)>=1200){
//                staticScreen.setWidth(staticScreen.getWidth()+(event.getScreenX()-xOffset));
//                xOffset = event.getScreenX();
//            }
//            if(staticScreen.getHeight()+(event.getScreenY()-yOffset)>=800){
//                staticScreen.setHeight(staticScreen.getHeight()+(event.getScreenY()-yOffset));
//                yOffset = event.getScreenY();
//            }
//        }); // 记得添加


        HBox hBox = new HBox(15);
        hBox.setPadding(new Insets(0,0,0,10));
        hBox.setPrefWidth(270);
        hBox.setAlignment(Pos.CENTER_LEFT);
        hBox.getChildren().addAll(label5,stackPane1,label6,label7);

        bottomPane.setLeft(hBox1);
        bottomPane.setCenter(borderPane);
        bottomPane.setRight(hBox);

        labelPlayTime.prefHeightProperty().bind(borderPane.prefHeightProperty());
        sliderSong.prefHeightProperty().bind(borderPane.prefHeightProperty());
        labelTotalTime.prefHeightProperty().bind(borderPane.prefHeightProperty());

        return bottomPane;
    }


    public static void main(String[] args) {

//        File musicFile = new File("./","AllMusic");
//        if (musicFile.mkdirs()) {
//            System.out.println("音乐文件夹创建成功！");
//        } else {
//            System.out.println("文件夹创建失败！");
//        }


        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql_1 = "set GLOBAL max_allowed_packet=33554432";
            PreparedStatement statement1 = con.prepareStatement(sql_1);
            statement1.execute();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }



        launch(args);
    }

}