package Main_APP.Main;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.StageStyle;
import javafx.scene.control.TextField;

import java.sql.*;

import javafx.scene.control.Button;

public class add_screen {
    private Stage parentStage; // 父窗体
    private VBox VBox; // 父窗体中歌单列表的vbox对象
    private MainAPP mainAPP;

    private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

//    本窗体的舞台对象
    private Stage stage;
    private double mouse_X;
    private double mouse_Y;

    public add_screen(Stage parentStage,VBox VBox, MainAPP mainAPP){
        this.parentStage = parentStage;
        this.VBox = VBox;
        this.mainAPP = mainAPP;

        Label label = new Label("新建歌单");
        label.setTextFill(Color.ORANGE);
        label.setPrefHeight(150);
        label.setPrefWidth(50);
        label.setLayoutX(10);
        label.setLayoutY(-10);

        // 关闭按钮
        ImageView close = new ImageView("image/black_X.png");
        close.setFitWidth(20);
        close.setFitHeight(20);

        Label label1 = new Label("",close);
        label1.setMinWidth(20);
        label1.setMinHeight(20);
        label1.setPrefHeight(20);
        label1.setPrefWidth(20);
        label1.setLayoutX(270);
        label1.setLayoutY(0);
        label1.setOnMouseEntered(event -> close.setImage(new Image("image/red_X.png")));
        label1.setOnMouseExited(event -> close.setImage(new Image("image/black_X.png")));
        label1.setOnMouseClicked(event -> stage.hide());

        //文本框
        TextField text_group_name = new TextField();
        text_group_name.setPromptText("请输入歌单名称");
        text_group_name.setPrefWidth(220);
        text_group_name.setPrefHeight(15);
        text_group_name.setLayoutX(20);
        text_group_name.setLayoutY(80);
        // 列表存在的提示框
        Label label2 = new Label();
        label2.setPrefWidth(200);
        label2.setLayoutX(20);
        label2.setLayoutY(110);
        label2.setTextFill(Color.RED);

//        确定按钮
        Button button_ok = new Button("确定");
        button_ok.setPrefWidth(80);
        button_ok.setPrefHeight(30);
        button_ok.setLayoutX(50);
        button_ok.setLayoutY(150);
        button_ok.setBackground(new Background(new BackgroundFill(Color.rgb(255, 185, 15),null,null)));
        button_ok.setOnMouseClicked(event -> {
            // 获取文本框数据
            String txt = text_group_name.getText().trim();
            if (txt.length() == 0){
                label2.setText("请输入歌单名称");
            } else {
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
                    Connection con = DriverManager.getConnection(URL, USER, PASS);
                    String sql_1 = "SELECT table_name FROM information_schema.TABLES WHERE table_name ='" + txt + "';";
                    PreparedStatement doing = con.prepareStatement(sql_1);
                    ResultSet result = doing.executeQuery();
                    if(!result.next()){
                        String sql_2 = "CREATE TABLE "+txt+" (" +
                                "id SMALLINT AUTO_INCREMENT NOT NULL PRIMARY KEY," +
                                "music_name VARCHAR(50), music_content LONGBLOB, music_type varchar(30) );";
                        Statement statement = con.createStatement();
                        statement.executeUpdate(sql_2);
                        // 创造hbox
                        ImageView love_image = new ImageView("image/vacant_love.png");
                        love_image.setFitWidth(20);
                        love_image.setPreserveRatio(true);
                        Label label_1 = new Label("",love_image);
                        label_1.setMinHeight(0);
                        label_1.setMinWidth(0);
                        label_1.setPrefWidth(20);
                        label_1.setPrefHeight(20);
                        label_1.setOnMouseEntered(event_1 -> love_image.setImage(new Image("image/red_love.png")));
                        label_1.setOnMouseExited(event_1 -> love_image.setImage(new Image("image/vacant_love.png")));

                        // 歌单名称
                        Label song_name_1 = new Label(txt);
                        song_name_1.setMinHeight(0);
                        song_name_1.setPrefHeight(20);
                        song_name_1.setPrefWidth(160);
                        song_name_1.setTextFill(Color.rgb(139, 69, 19));
                        //这里有一个移入高亮
                        song_name_1.setOnMouseEntered(event_1 -> song_name_1.setTextFill(Color.rgb(255, 127, 0)));
                        song_name_1.setOnMouseExited(event_1 -> song_name_1.setTextFill(Color.rgb(139, 69, 19)));

                        // 播放按钮
                        ImageView iv2 = new ImageView("image/play_while.png");
                        iv2.setFitWidth(20);
                        iv2.setPreserveRatio(true);
                        Label label_2 = new Label("",iv2);
                        label_2.setMinHeight(0);
                        label_2.setMinWidth(0);
                        label_2.setPrefWidth(20);
                        label_2.setPrefHeight(20);
                        label_2.setOnMouseEntered(event_1 -> iv2.setImage(new Image("image/play_green.png")));
                        label_2.setOnMouseExited(event_1 -> iv2.setImage(new Image("image/play_while.png")));

                        ImageView imageView = new ImageView("image/small_add.png");
                        imageView.setFitWidth(20);
                        imageView.setPreserveRatio(true);
                        Label label_3 = new Label("",imageView);
                        label_3.setMinHeight(0);
                        label_3.setMinWidth(0);
                        label_3.setPrefWidth(20);
                        label_3.setPrefHeight(20);
                        label_3.setOnMouseEntered(event_1 -> {imageView.setImage(new Image("image/blue_add.png"));});
                        label_3.setOnMouseExited(event_1 -> {imageView.setImage(new Image("image/small_add.png"));});

                        // 垃圾桶;
                        ImageView iv3 = new ImageView("image/ash-bin_dark.png");
                        iv3.setFitWidth(20);
                        iv3.setPreserveRatio(true);
                        Label label_4 = new Label("",iv3);
                        label_4.setMinHeight(0);
                        label_4.setMinWidth(0);
                        label_4.setPrefWidth(20);
                        label_4.setPrefHeight(20);
                        label_4.setOnMouseEntered(event_1 -> iv3.setImage(new Image("image/ash-bin_colorful.png")));
                        label_4.setOnMouseExited(event_1 -> iv3.setImage(new Image("image/ash-bin_dark.png")));
                        HBox hBox1 = new HBox(10);//间距10
                        hBox1.getChildren().addAll(label_1,song_name_1,label_2,label_3,label_4);
                        hBox1.setPadding(new Insets(5,5,5,10));
                        // 更新列表
                        this.VBox.getChildren().add(hBox1);
                        label2.setText("创造成功");
                        this.stage.hide();
                    }else {
                        label2.setText("歌单已经存在");
                    }
                }catch (ClassNotFoundException | SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });


        // 取消
        Button button_cancel = new Button("取消");
        button_cancel.setPrefWidth(80);
        button_cancel.setPrefHeight(30);
        button_cancel.setLayoutX(150);
        button_cancel.setLayoutY(150);  //这地方可以修改
        button_cancel.setBackground(new Background(new BackgroundFill(Color.rgb(255, 255, 224),null,null)));
        button_cancel.setOnMouseClicked(event -> stage.hide());

        // 创造一个舞台对象 就是大概底板 或者地基
        stage = new Stage();
        stage.initStyle(StageStyle.UNDECORATED);
        // 创造一个场景
        Group group = new Group();
        group.getChildren().addAll(label,label1,text_group_name,label2,button_ok,button_cancel);
        Scene scene = new Scene(group,300,180);
        scene.setOnMousePressed(event -> {
            mouse_X = event.getSceneX();
            mouse_Y = event.getSceneY();
        }); // 场景的拖拽
        scene.setOnMouseDragged(event -> {
            stage.setX(event.getScreenX()-mouse_X);
            stage.setY(event.getScreenY()-mouse_Y);
        });


        // 设置场景
        stage.setScene(scene);
        stage.show();
    }


}
