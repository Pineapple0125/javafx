package Main_APP.Main;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;

public class search_song {
    public String filepath;
    public String fileName;

    private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public String getFilepath() {
        return filepath;
    }

    public search_song(String filepath,String fileName){
        this.filepath = filepath;
        this.fileName = fileName;
    }

    public static ArrayList<search_song> Search(String key){
        ArrayList<search_song> song_list = new ArrayList<>();

        try{
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql = "select table_name from information_schema.tables where table_schema='database_name'";
            PreparedStatement doing = con.prepareStatement(sql);
            PreparedStatement statement;
            ResultSet result = doing.executeQuery();
            while (result.next()){
                String sql_1 = "select * from "+result.getString("table_name")+" where (music_name like '%"+key+"%' or music_type like '%"+key+"%' or album like '%"+key+"%' or artist like '%"+key+"%')";
                statement = con.prepareStatement(sql_1);
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()){

                    System.out.println(resultSet.getString("music_name"));

                    File temp = File.createTempFile(resultSet.getString("music_name").substring(0, resultSet.getString("music_name").indexOf(".")), ".mp3");
                    temp.deleteOnExit();
                    try (BufferedOutputStream bop=new BufferedOutputStream(Files.newOutputStream(Paths.get(temp.getPath())))) {
                        InputStream inputStream = resultSet.getBinaryStream("music_content");
                        byte[] z = new byte[1024]; // 一次读取1024位数据

                        while (inputStream.read(z)!=-1){ // 终止条件 如果因为流位于文件末尾而没有可用的字节，则返回值 -1
                            bop.write(z);
                        }
                    }
                    song_list.add(new search_song(temp.getPath(),resultSet.getString("music_name")));

                }
            }
        } catch (SQLException | ClassNotFoundException | IOException e) {
            throw new RuntimeException(e);
        }


//        try{
//            String sql_1 = "select music_name from all_music where (music_name like '%"+key+"%' or music_type like '%"+key+"%' or album like '%"+key+"%' or artist like '%"+key+"%')";
//            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
//            Connection con = DriverManager.getConnection(URL,USER,PASS);
//            Statement statement=con.prepareStatement(sql_1); //create接口
//            PreparedStatement statement_1;
//            ResultSet resultSet = statement.executeQuery(sql_1);
//            while (resultSet.next()) {
//
//                String sql_2 = "select * from all_music where music_name = '" +resultSet.getString("music_name") +"'";
//
//                File temp = File.createTempFile(resultSet.getString("music_name").substring(0, resultSet.getString("music_name").indexOf(".")), ".mp3");
////                temp.deleteOnExit();
//                System.out.println(temp.getAbsolutePath() + " search ");
//                System.out.println(temp.getName() + " search ");
//
////                String path = "AllMusic/"+ resultSet.getString("music_name")+"";
////                File file = new File(path);
//
////                if (!file.exists()){
////                    System.out.println(path);
//                try (BufferedOutputStream bop=new BufferedOutputStream(Files.newOutputStream(Paths.get(temp.getPath())))){
//                    statement_1=con.prepareStatement(sql_2);
//                    ResultSet result = statement_1.executeQuery(sql_2);
//                    while (result.next()){
//                        InputStream inputStream = result.getBinaryStream("music_content");
//                        byte[] z = new byte[1024]; // 一次读取1024位数据
//
//                        while (inputStream.read(z)!=-1){ // 终止条件 如果因为流位于文件末尾而没有可用的字节，则返回值 -1
//                            bop.write(z);
//                        }
//                    }
//
//
//                    } catch (IOException | SQLException e) {
//                        throw new RuntimeException(e);
//                    }
////                }
//                song_list.add(new search_song(temp.getPath(),resultSet.getString("music_name")));
//                statement_1.close();
//            }
//
//            con.close();
//            statement.close();
//
//        } catch (ClassNotFoundException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException | IOException e) {
//            throw new RuntimeException(e);
//
//        }
        return song_list;

    }

}

