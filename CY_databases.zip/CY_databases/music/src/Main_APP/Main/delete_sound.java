package Main_APP.Main;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class delete_sound {
    private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public static void delete(String song_name,String song_table_name){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql = "DELETE FROM "+song_table_name+" WHERE music_name =  '"+song_name+"'";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.executeUpdate();
            statement.close();
            con.close();
        }catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

}
