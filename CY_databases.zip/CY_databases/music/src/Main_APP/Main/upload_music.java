package Main_APP.Main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;


public class upload_music {
        private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
        private static final String USER="root"; //连接用户
        private static final String PASS="Seele1018"; // 连接密码


        public static boolean upload (File file,String name){
//            try {
//                Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
//                Connection con = DriverManager.getConnection(URL,USER,PASS);
//                String sql_1 = "set GLOBAL max_allowed_packet=33554432";
//                PreparedStatement statement1 = con.prepareStatement(sql_1);
//                statement1.execute();
//            } catch (ClassNotFoundException e) {
//                // TODO Auto-generated catch block
//                e.printStackTrace();
//            } catch (SQLException e) {
//                throw new RuntimeException(e);
//            }

            try{
                Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
                Connection con = DriverManager.getConnection(URL,USER,PASS);
                String sql0 = "select music_name from "+name+ " where music_name = '"+file.getName()+"';";
//                这里是先搜索看看原歌单里存不存在这首歌 不存在就添加
                System.out.println(name);
                System.out.println(file.getName());
                PreparedStatement statement_0=con.prepareStatement(sql0); //create接口
                ResultSet resultSet = statement_0.executeQuery(sql0);
                if (!resultSet.next()){
                    FileInputStream song_byte = new FileInputStream(file);
                    String sql="insert into "+name+"(music_name,music_content) values(?,?);"; //MySQL语句插入
                    PreparedStatement statement_1=con.prepareStatement(sql); //create接口
                    statement_1.setString(1,file.getName()); //第一个空填的东西
                    statement_1.setBinaryStream(2, song_byte, ((InputStream) song_byte).available()); // 第二个空填的东西
                    statement_1.execute();

                    con.close();
                    statement_0.close();
                    statement_1.close();

                    return true;
                }
                else {
                    return false;
                }

            }
            catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException | IOException e) {
                throw new RuntimeException(e);
            }
        return false;
        }
    }

