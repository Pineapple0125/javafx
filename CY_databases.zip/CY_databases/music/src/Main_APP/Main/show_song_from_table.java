package Main_APP.Main;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;

public class show_song_from_table {
    public String filepath;
    public String fileName;

    private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码


//    public show_song_from_table(){} //无参构造

    public String getFilepath() {
        return filepath;
    }
//    public void setFilepath(String filepath) {
//        this.filepath = filepath;
//    }
//
//    public String getfileName() {
//        return fileName;
//    }
//
//    public void setfileName(String fileName) {
//        this.fileName = fileName;
//    }

    public show_song_from_table(String filepath,String fileName){
        this.filepath = filepath;
        this.fileName = fileName;
    }

    public static ArrayList<show_song_from_table> ADD(String table_name){
        ArrayList<show_song_from_table> song_list = new ArrayList<>();

        try{
            String sql_1 = "select music_name from  "+table_name+"; ";
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            Statement statement=con.prepareStatement(sql_1); //create接口
            PreparedStatement statement_1;
            ResultSet resultSet = statement.executeQuery(sql_1);
            while (resultSet.next()) {
                System.out.println(resultSet.getString("music_name"));
                String sql_2 = "select * from "+table_name+" where music_name = '" +resultSet.getString("music_name") +"'";
//                String path = "AllMusic/"+ resultSet.getString("music_name")+"";
//                File file = new File(path);
                File temp = File.createTempFile(resultSet.getString("music_name").substring(0, resultSet.getString("music_name").indexOf(".")), ".mp3");
                temp.deleteOnExit();

//                if (!temp.exists()){
                try (BufferedOutputStream bop=new BufferedOutputStream(Files.newOutputStream(Paths.get(temp.getPath())))){
                    statement_1=con.prepareStatement(sql_2);
                    ResultSet result = statement_1.executeQuery(sql_2);
                    while (result.next()){
                        InputStream inputStream = result.getBinaryStream("music_content");
                        byte[] z = new byte[1024]; // 一次读取1024位数据

                        while (inputStream.read(z)!=-1){ // 终止条件 如果因为流位于文件末尾而没有可用的字节，则返回值 -1
                            bop.write(z);
                        }
                    }

                } catch (IOException | SQLException e) {
                    throw new RuntimeException(e);
                    }
//                }
                song_list.add(new show_song_from_table(temp.getPath(),resultSet.getString("music_name")));
                statement_1.close();
            }
        con.close();
        statement.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException | IOException e) {
            throw new RuntimeException(e);

        }
        return song_list;

    }

}


