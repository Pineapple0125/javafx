package Main_APP.Main;

import javafx.scene.control.Label;
import javafx.scene.image.WritableImage;
import javafx.scene.media.MediaPlayer;

import java.sql.*;


public class PlayBean {
    private int id; // 序号
    private String soundName; // 音乐标题
    private String artist; // 歌唱家
    private String album ; //  专辑名称
    private  String length; // 大小
    private String time; // 时长
    private WritableImage image; // 时长

    private int totalSeconds; // 总秒数
    private String filePath; //
    private MediaPlayer mediaPlayer; // 播放器
    private Label labDelete; //删除图标
    private String lrcPath; // 歌词路径


    private String soundType;

    private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码




    public PlayBean(){}

//    public PlayBean(int id, String soundName, String artist, String album, String length, String time, WritableImage image, int totalSeconds, String filePath, MediaPlayer mediaPlayer, Label labDelete, String lrcPath, String soundType) {
//        this.id = id;
//        this.soundName = soundName;
//        this.artist = artist;
//        this.album = album;
//        this.length = length;
//        this.time = time;
//        this.image = image;
//        this.totalSeconds = totalSeconds;
//        this.filePath = filePath;
//        this.mediaPlayer = mediaPlayer;
//        this.labDelete = labDelete;
//        this.lrcPath = lrcPath;
//        this.soundType = soundType;
//    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSoundName() {
        return soundName;
    }

    public void setSoundName(String soundName) {
        this.soundName = soundName;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getTime() {
        return time;
    }

    @Override
    public String toString() {
        return "PlayBean{" +
                "id=" + id +
                ", soundName='" + soundName + '\'' +
                ", artist='" + artist + '\'' +
                ", album='" + album + '\'' +
                ", length='" + length + '\'' +
                ", time='" + time + '\'' +
                ", image=" + image +
                ", totalSeconds=" + totalSeconds +
                ", filePath='" + filePath + '\'' +
                ", mediaPlayer=" + mediaPlayer +
                ", labDelete=" + labDelete +
                ", lrcPath='" + lrcPath + '\'' +
                ", soundType='" + soundType + '\'' +
                '}';
    }

    public void setTime(String time) {
        this.time = time;
    }

    public WritableImage getImage() {
        return image;
    }

    public void setImage(WritableImage image) {
        this.image = image;
    }

    public int getTotalSeconds() {
        return totalSeconds;
    }

    public void setTotalSeconds(int totalSeconds) {
        this.totalSeconds = totalSeconds;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    public void setMediaPlayer(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    public Label getLabDelete() {
        return labDelete;
    }

    public void setLabDelete(Label labDelete) {
        this.labDelete = labDelete;
    }

    public String getLrcPath() {
        return lrcPath;
    }

    public void setLrcPath(String lrcPath) {
        this.lrcPath = lrcPath;
    }


    public String getSoundType() {


        return soundType;
    }

    public void setSoundType(String table_name,String name) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            String  sql = "select music_type from "+table_name+" where music_name = '"+name+"'   ";
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            Statement statement=con.prepareStatement(sql); //create接口
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                this.soundType = resultSet.getString("music_type");
            }else {
                this.soundType = "暂无";
            }

        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("error");
            this.soundType = "暂无";
        }
    }


//    public String getSoundType(String table_name,String name) {
//        try {
//            System.out.println("123456789");
//            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
//            String  sql = "select music_type from '"+table_name+"' where music_name = '"+name+"'   ";
//            Connection con = DriverManager.getConnection(URL,USER,PASS);
//            Statement statement=con.prepareStatement(sql); //create接口
//            ResultSet resultSet = statement.executeQuery(sql);
//            System.out.println("123456"+(resultSet.getString("music_type")));
//            return "soundType";
//        } catch (SQLException | ClassNotFoundException e) {
//            System.out.println("error");
//            return "SoundType";
//        }
//    }
//
//    public void setSoundType(String soundType) {
//        this.soundType = soundType;
//    }


//    @Override
//    public String toString() {
//        return "PlayBean{" +
//                "id=" + id +
//                ", soundName='" + soundName + '\'' +
//                ", artist='" + artist + '\'' +
//                ", album='" + album + '\'' +
//                ", length='" + length + '\'' +
//                ", time='" + time + '\'' +
//                ", image=" + image +
//                ", totalSeconds=" + totalSeconds +
//                ", filePath='" + filePath + '\'' +
//                ", mediaPlayer=" + mediaPlayer +
//                ", labDelete=" + labDelete +
//                ", lrcPath='" + lrcPath + '\'' +
//                '}';
//    }
}
