package Main_APP.Main;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class search_table {
    private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public static List<String> readAllGroup(){
        List<String> groupList = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = (Connection) DriverManager.getConnection(URL,USER,PASS);
            String sql_1 = "select table_name from information_schema.tables where (table_schema = 'database_name' )";
            PreparedStatement doing = con.prepareStatement(sql_1);
            ResultSet result = doing.executeQuery();
            while (result.next()){
                String pic_name = result.getString("table_name");
                groupList.add(pic_name);
            }
            doing.close();
            con.close();
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return groupList;
    }
}
