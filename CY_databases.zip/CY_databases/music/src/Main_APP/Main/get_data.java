package Main_APP.Main;

import java.sql.*;

public class get_data {

    private static final String  URL="jdbc:mysql://localhost:3306/database_name"; //连接数据库位置
    private static final String USER="root"; //连接用户
    private static final String PASS="Seele1018"; // 连接密码

    public static String get_artist(String song_name){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql = "select artist from all_music where music_name = '"+song_name+"';";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery(sql);
            if (resultSet.next()){
                System.out.println(resultSet.getString("artist"));
                return resultSet.getString("artist");
            }
            else
                return null;
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }

    }


    public static String get_album(String song_name){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //连接密钥
            Connection con = DriverManager.getConnection(URL,USER,PASS);
            String sql = "select album from all_music where music_name = '"+song_name+"';";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery(sql);

            if (resultSet.next()){
                System.out.println(resultSet.getString("album"));
                return resultSet.getString("album");
            }
            else
                return null;
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }

    }

}
